(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=[{symbol:`H`,name:`Hydrogen`,atomicNumber:1,mass:1.00794},{symbol:`He`,name:`Helium`,atomicNumber:2,mass:4.002602},{symbol:`Li`,name:`Lithium`,atomicNumber:3,mass:6.941},{symbol:`Be`,name:`Beryllium`,atomicNumber:4,mass:9.012182},{symbol:`B`,name:`Boron`,atomicNumber:5,mass:10.811},{symbol:`C`,name:`Carbon`,atomicNumber:6,mass:12.0107},{symbol:`N`,name:`Nitrogen`,atomicNumber:7,mass:14.0067},{symbol:`O`,name:`Oxygen`,atomicNumber:8,mass:15.9994},{symbol:`F`,name:`Fluorine`,atomicNumber:9,mass:18.9984032},{symbol:`Ne`,name:`Neon`,atomicNumber:10,mass:20.1797},{symbol:`Na`,name:`Sodium`,atomicNumber:11,mass:22.98977},{symbol:`Mg`,name:`Magnesium`,atomicNumber:12,mass:24.305},{symbol:`Al`,name:`Aluminium`,atomicNumber:13,mass:26.981538},{symbol:`Si`,name:`Silicon`,atomicNumber:14,mass:28.0855},{symbol:`P`,name:`Phosphorus`,atomicNumber:15,mass:30.973762},{symbol:`S`,name:`Sulfur`,atomicNumber:16,mass:32.065},{symbol:`Cl`,name:`Chlorine`,atomicNumber:17,mass:35.453},{symbol:`Ar`,name:`Argon`,atomicNumber:18,mass:39.948},{symbol:`K`,name:`Potassium`,atomicNumber:19,mass:39.0983},{symbol:`Ca`,name:`Calcium`,atomicNumber:20,mass:40.078},{symbol:`Sc`,name:`Scandium`,atomicNumber:21,mass:44.955912},{symbol:`Ti`,name:`Titanium`,atomicNumber:22,mass:47.867},{symbol:`V`,name:`Vanadium`,atomicNumber:23,mass:50.9415},{symbol:`Cr`,name:`Chromium`,atomicNumber:24,mass:51.9961},{symbol:`Mn`,name:`Manganese`,atomicNumber:25,mass:54.938045},{symbol:`Fe`,name:`Iron`,atomicNumber:26,mass:55.845},{symbol:`Co`,name:`Cobalt`,atomicNumber:27,mass:58.933195},{symbol:`Ni`,name:`Nickel`,atomicNumber:28,mass:58.6934},{symbol:`Cu`,name:`Copper`,atomicNumber:29,mass:63.546},{symbol:`Zn`,name:`Zinc`,atomicNumber:30,mass:65.38},{symbol:`Ga`,name:`Gallium`,atomicNumber:31,mass:69.723},{symbol:`Ge`,name:`Germanium`,atomicNumber:32,mass:72.64},{symbol:`As`,name:`Arsenic`,atomicNumber:33,mass:74.9216},{symbol:`Se`,name:`Selenium`,atomicNumber:34,mass:78.96},{symbol:`Br`,name:`Bromine`,atomicNumber:35,mass:79.904},{symbol:`Kr`,name:`Krypton`,atomicNumber:36,mass:83.798},{symbol:`Rb`,name:`Rubidium`,atomicNumber:37,mass:85.4678},{symbol:`Sr`,name:`Strontium`,atomicNumber:38,mass:87.62},{symbol:`Y`,name:`Yttrium`,atomicNumber:39,mass:88.90585},{symbol:`Zr`,name:`Zirconium`,atomicNumber:40,mass:91.224},{symbol:`Nb`,name:`Niobium`,atomicNumber:41,mass:92.90638},{symbol:`Mo`,name:`Molybdenum`,atomicNumber:42,mass:95.96},{symbol:`Tc`,name:`Technetium`,atomicNumber:43,mass:98},{symbol:`Ru`,name:`Ruthenium`,atomicNumber:44,mass:101.07},{symbol:`Rh`,name:`Rhodium`,atomicNumber:45,mass:102.9055},{symbol:`Pd`,name:`Palladium`,atomicNumber:46,mass:106.42},{symbol:`Ag`,name:`Silver`,atomicNumber:47,mass:107.8682},{symbol:`Cd`,name:`Cadmium`,atomicNumber:48,mass:112.411},{symbol:`In`,name:`Indium`,atomicNumber:49,mass:114.818},{symbol:`Sn`,name:`Tin`,atomicNumber:50,mass:118.71},{symbol:`Sb`,name:`Antimony`,atomicNumber:51,mass:121.76},{symbol:`Te`,name:`Tellurium`,atomicNumber:52,mass:127.6},{symbol:`I`,name:`Iodine`,atomicNumber:53,mass:126.90447},{symbol:`Xe`,name:`Xenon`,atomicNumber:54,mass:131.293}],t=Object.freeze(Object.fromEntries(e.map(e=>[e.atomicNumber,Object.freeze({...e})]))),n=Object.freeze(Object.fromEntries(e.map(e=>[e.symbol,Object.freeze({...e})])));function r(e){let n=t[e];return n?n.symbol:null}function i(e){if(typeof e!=`string`||e.length===0)return null;let t=n[e.charAt(0).toUpperCase()+e.slice(1).toLowerCase()];return t?t.atomicNumber:null}function a(e){if(!e||e.length===0)return`molecule`;let t={};for(let n of e){let e=n.symbol;t[e]=(t[e]||0)+1}let n=``;if(t.C){n+=`C${t.C>1?t.C:``}`,t.H&&(n+=`H${t.H>1?t.H:``}`);let e=Object.keys(t).filter(e=>e!==`C`&&e!==`H`).sort();for(let r of e)n+=`${r}${t[r]>1?t[r]:``}`}else{let e=Object.keys(t).sort();for(let r of e)n+=`${r}${t[r]>1?t[r]:``}`}return n}var o=30;function s(e){let t=e.getAttribute(`NodeType`);return!t||new Set([`Unspecified`,`Element`,`GenericNickname`,`Fragment`,``]).has(t)}function c(e){if(!e)return{x:0,y:0};let t=e.trim().split(/\s+/).map(Number);return{x:(t[0]||0)/o,y:(t[1]||0)/o}}function l(e){if(!e||typeof e!=`string`||e.trim().length===0)throw Error(`CDXML input must be a non-empty string.`);let n=new DOMParser().parseFromString(e,`application/xml`),r=n.querySelector(`parsererror`);if(r)throw Error(`Malformed CDXML: ${r.textContent.slice(0,200)}`);let i=[],a=[],o=new Set,l=n.querySelectorAll(`n`);for(let e of l){if(!s(e))continue;let n=e.getAttribute(`id`);if(!n)continue;let r=e.getAttribute(`Element`),a=r?parseInt(r,10):6,l=t[a],u=l?l.symbol:`X${a}`,d=c(e.getAttribute(`p`)||e.getAttribute(`2DPosition`));i.push({id:n,symbol:u,x:d.x,y:d.y,z:0}),o.add(n)}let u=n.querySelectorAll(`b`);for(let e of u){let t=e.getAttribute(`B`),n=e.getAttribute(`E`);if(!t||!n||!o.has(t)||!o.has(n))continue;let r=e.getAttribute(`Order`),i=r?parseInt(r,10):1;a.push({from:t,to:n,order:isNaN(i)?1:i})}if(i.length===0)throw Error(`No valid atoms found in CDXML file. Ensure the file contains <n> elements within <fragment> elements.`);return{atoms:i,bonds:a,smiles:null}}function u(e){if(!e||typeof e!=`string`||e.trim().length===0)throw Error(`MOL file content must be a non-empty string.`);let t=e.replace(/\r\n/g,`
`).replace(/\r/g,`
`).split(`
`);if(t.length<5)throw Error(`MOL file is too short — at least 5 lines are required (header + counts + M END).`);let n=t[0].trim(),r=t[3];if(r.length<6)throw Error(`Invalid counts line in MOL file (line 4 is too short).`);let i=parseInt(r.substring(0,3).trim(),10),a=parseInt(r.substring(3,6).trim(),10);if(isNaN(i)||i<0)throw Error(`Invalid atom count "${r.substring(0,3).trim()}" in MOL counts line.`);if(isNaN(a)||a<0)throw Error(`Invalid bond count "${r.substring(3,6).trim()}" in MOL counts line.`);let o=4+i+a;if(t.length<o)throw Error(`MOL file declares ${i} atoms and ${a} bonds but has only ${t.length} lines (need at least ${o}).`);let s=[];for(let e=0;e<i;e++){let n=t[4+e];if(n.length<34)throw Error(`Atom line ${e+1} is too short (${n.length} chars, need ≥ 34).`);let r=parseFloat(n.substring(0,10).trim()),i=parseFloat(n.substring(10,20).trim()),a=parseFloat(n.substring(20,30).trim()),o=n.substring(30,34).trim();if(isNaN(r)||isNaN(i)||isNaN(a))throw Error(`Invalid coordinates on atom line ${e+1}: "${n.substring(0,30)}".`);if(!o)throw Error(`Missing element symbol on atom line ${e+1}.`);s.push({symbol:o,x:r,y:i,z:a})}let c=[];for(let e=0;e<a;e++){let n=t[4+i+e];if(n.length<9)throw Error(`Bond line ${e+1} is too short (${n.length} chars, need ≥ 9).`);let r=parseInt(n.substring(0,3).trim(),10),a=parseInt(n.substring(3,6).trim(),10),o=parseInt(n.substring(6,9).trim(),10);if(isNaN(r)||isNaN(a))throw Error(`Invalid atom indices on bond line ${e+1}: "${n.substring(0,6)}".`);if(r<1||r>i||a<1||a>i)throw Error(`Bond line ${e+1} references atom ${r} or ${a}, but only ${i} atoms are defined.`);c.push({from:r,to:a,order:isNaN(o)?1:o})}return{atoms:s,bonds:c,name:n}}function d(e){if(!e||typeof e!=`string`||e.trim().length===0)throw Error(`SDF file content must be a non-empty string.`);let t=e.indexOf(`$$$$`),n;n=t===-1?e:e.substring(0,t);let r=n.indexOf(`M  END`);return r!==-1&&(n=n.substring(0,r+6)),u(n)}function f(e){if(!e||typeof e!=`string`||e.trim().length===0)throw Error(`XYZ file content must be a non-empty string.`);let t=e.replace(/\r\n/g,`
`).replace(/\r/g,`
`).split(`
`),n=0;for(;n<t.length&&t[n].trim()===``;)n++;if(n>=t.length)throw Error(`XYZ file contains no non-blank lines.`);let a=t[n].trim(),o=Number(a);if(!/^\d+$/.test(a)||!Number.isSafeInteger(o)||o<1)throw Error(`First line of XYZ file must be a positive integer atom count, got "${a}".`);let s=n+1<t.length?t[n+1].trim():``,c=[],l=n+2;for(;l<t.length&&c.length<o;){let e=t[l].trim();if(l++,e===``)continue;let a=e.split(/\s+/);if(a.length<4)throw Error(`XYZ atom line ${l-n} has ${a.length} fields (need ≥ 4): "${e}".`);let o=a[0],s;if(s=/^\d+$/.test(o)?r(Number(o)):o.charAt(0).toUpperCase()+o.slice(1).toLowerCase(),!s||i(s)===null)throw Error(`Unknown element in XYZ atom line ${l-n}: "${o}".`);let u=a.slice(1,4).map(Number);if(!u.every(Number.isFinite))throw Error(`Invalid coordinates on XYZ line ${l-n}: "${e}".`);c.push({symbol:s,x:u[0],y:u[1],z:u[2]})}if(c.length!==o)throw Error(`XYZ file declares ${o} atoms but only found ${c.length}.`);return{atoms:c,title:s}}var p=`modulepreload`,m=function(e,t){return new URL(e,t).href},h={},g=function(e){return e.pathname.endsWith(`.css`)},_=function(e,t,n){if(t in e)return e[t];let r=n();if(!r){e[t]=void 0;return}let i=r.then(()=>{e[t]=void 0},n=>{throw e[t]=void 0,n});return e[t]=i,i},v=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e,i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?new URL(import.meta.resolve(e)):new URL(e,import.meta.url)}r=o(t.map(t=>{t=m(t,n);let r=s(t),i=g(r);return _(h,r.href,()=>{if(e===void 0){e={all:new Set,styles:new Set};let t=document.getElementsByTagName(`link`);for(let n=t.length-1;n>=0;n--){let r=t[n];e.all.add(r.href),r.rel===`stylesheet`&&e.styles.add(r.href)}}if((i?e.styles:e.all).has(r.href))return;let t=document.createElement(`link`);if(t.rel=i?`stylesheet`:p,i||(t.as=`script`),t.crossOrigin=``,t.href=r.href,a&&t.setAttribute(`nonce`,a),document.head.appendChild(t),i)return new Promise((e,n)=>{let i=a=>{t.removeEventListener(`load`,i),t.removeEventListener(`error`,i),a.type===`error`?n(Error(`Unable to preload CSS for ${r}`)):e(a)};t.addEventListener(`load`,i),t.addEventListener(`error`,i)})})}).filter(e=>e!==void 0))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},y=/^[A-Za-z0-9@+\-\[\]\(\)\\\/=#%.$:~*!]+$/;async function b(e){if(!e||typeof e!=`string`)throw Error(`SMILES input must be a non-empty string.`);let t=e.trim();if(t.length===0)throw Error(`SMILES input must be a non-empty string.`);if(!y.test(t)){let e=[...t].find(e=>!y.test(e));throw Error(`SMILES string contains invalid character "${e}". Only atoms, bonds, branches, rings, and stereochemistry tokens are allowed.`)}let n=0;for(let e of t)if(e===`[`&&n++,e===`]`&&n--,n<0)throw Error(`SMILES string has an unmatched closing bracket "]".`);if(n!==0)throw Error(`SMILES string has an unmatched opening bracket "[".`);let r=0;for(let e of t)if(e===`(`&&r++,e===`)`&&r--,r<0)throw Error(`SMILES string has an unmatched closing parenthesis ")".`);if(r!==0)throw Error(`SMILES string has an unmatched opening parenthesis "(".`);try{let{smilesTo3D:e}=await v(async()=>{let{smilesTo3D:e}=await import(`./coordGenerator-C5sFl01B.js`);return{smilesTo3D:e}},[],import.meta.url),n=e(t);if(!n.atoms||n.atoms.length===0)throw Error(`SMILES produced a molecule with no atoms.`);return{atoms:n.atoms,molfile:n.molfile,smiles:t}}catch(e){throw e.message.includes(`Invalid SMILES`)?e:Error(`Failed to process SMILES "${t}": ${e.message}`)}}var x=new Set([`AM1`,`PM3`,`PM6`,`PM7`,`MNDO`,`MINDO3`,`INDO`,`CNDO`,`ZINDO`,`PDDG`,`RM1`]),S=new Set([`UFF`,`DREIDING`,`AMBER`,`MM2`,`MM3`,`MM4`]),C=new Set([`CBS-QB3`,`CBS-4M`,`CBS-APNO`,`G1`,`G2`,`G2MP2`,`G3`,`G3B3`,`G3MP2`,`G3MP2B3`,`G4`,`G4MP2`,`W1U`,`W1BD`,`W1RO`,`W2U`,`W2BD`]);function w(e){if(!e)return!1;let t=e.toUpperCase().trim();return!(x.has(t)||S.has(t)||C.has(t))}function T(e,t,n){try{if(!Number.isInteger(e))return{valid:!1,message:`Charge must be an integer.`};if(!Number.isInteger(t)||t<1)return{valid:!1,message:`Multiplicity must be a positive integer (≥ 1).`};if(!Array.isArray(n)||n.length===0)return{valid:!1,message:`At least one atom is required to validate charge/multiplicity.`};let r=0;for(let e of n){let t=typeof e==`string`?e:e.symbol,n=i(t);if(n===null)return{valid:!1,message:`Unknown element symbol: "${t}".`};r+=n}if(r-=e,r<0)return{valid:!1,message:`Charge of ${e} would result in a negative electron count (${r}).`};let a=t-1;return r%2==a%2?a>r?{valid:!1,message:`Multiplicity ${t} requires ${a} unpaired electrons, but only ${r} electrons are available.`}:{valid:!0,message:`Charge and multiplicity are consistent.`}:{valid:!1,message:`Multiplicity ${t} is inconsistent with ${r} electrons. An ${r%2==0?`even`:`odd`} electron count requires ${r%2==0?`odd`:`even`} multiplicity (1, 3, 5, … or 2, 4, 6, …).`}}catch(e){return{valid:!1,message:`Validation error: ${e.message}`}}}function E(e,t){try{if(!e||e.trim().length===0)return{valid:!1,message:`A computational method must be specified.`};let n=e.trim(),r=n.toUpperCase(),i=t&&t.trim().length>0,a=w(n);if(!a&&i){let e=`This method`;return x.has(r)?e=`Semi-empirical method "${n}"`:S.has(r)?e=`Molecular mechanics method "${n}"`:C.has(r)&&(e=`Composite method "${n}"`),{valid:!1,message:`${e} does not use an external basis set. Remove the basis set or choose a different method.`}}return a&&!i?{valid:!1,message:`Method "${n}" requires a basis set.`}:{valid:!0,message:`Method and basis set are compatible.`}}catch(e){return{valid:!1,message:`Validation error: ${e.message}`}}}function D(e){let t=[];try{if(e?.route?.method&&e.route.method.trim().length!==0||t.push(`Computational method is required.`),e?.route?.method&&w(e.route.method.trim())&&(e.route.basisSet&&e.route.basisSet.trim().length!==0||t.push(`Basis set is required for this method.`)),e?.route?.jobType&&e.route.jobType.trim().length!==0||t.push(`Job type is required (e.g. "Opt", "Freq", "SP").`),e?.title&&e.title.trim().length!==0||t.push(`A title/description is required.`),e?.charge!==void 0&&e?.charge!==null&&Number.isInteger(e.charge)||t.push(`Charge must be specified as an integer.`),(e?.multiplicity===void 0||e?.multiplicity===null||!Number.isInteger(e.multiplicity)||e.multiplicity<1)&&t.push(`Multiplicity must be a positive integer (≥ 1).`),!Array.isArray(e?.atoms)||e.atoms.length===0)t.push(`At least one atom with coordinates is required.`);else{for(let n=0;n<e.atoms.length;n++){let r=e.atoms[n];!r.symbol||typeof r.symbol!=`string`?t.push(`Atom ${n+1}: missing or invalid element symbol.`):i(r.symbol)===null&&t.push(`Atom ${n+1}: unknown element symbol "${r.symbol}".`),[r.x,r.y,r.z].every(Number.isFinite)||t.push(`Atom ${n+1} (${r.symbol||`?`}): coordinates must be finite numbers.`)}if(t.length===0&&Number.isInteger(e.charge)&&Number.isInteger(e.multiplicity)){let n=T(e.charge,e.multiplicity,e.atoms);n.valid||t.push(n.message)}}if(e?.route?.method){let n=E(e.route.method,e.route.basisSet);n.valid||t.push(n.message)}}catch(e){t.push(`Unexpected validation error: ${e.message}`)}return{valid:t.length===0,errors:t}}function ee(e){let t=[];if(!e)return t;let n=Array.isArray(e.atoms)?e.atoms:[],r=e.route||{},a=(r.method||``).trim().toUpperCase(),o=(r.basisSet||``).trim().toUpperCase(),s=Number.isInteger(e.charge)?e.charge:0,c=(r.jobType||``).trim().toUpperCase(),l=(r.dispersion||``).trim(),u=!1,d=!1;for(let e of n){let t=e.symbol,n=i(t);n!==null&&(n>36&&(u=!0),(n>=21&&n<=30||n>=39&&n<=48||n>=72&&n<=80)&&(d=!0))}let f=o.includes(`6-31`)||o.includes(`3-21`),p=o.startsWith(`CC-PV`)||o.startsWith(`AUG-CC-PV`);u&&(f||p)?t.push(`Heavy elements (Z > 36) are present. Standard basis sets like ${r.basisSet||`none`} may fail or lack parameters. Consider using an Effective Core Potential (ECP) basis set (e.g., LanL2DZ or SDD) or a Karlsruhe basis set (e.g., def2-TZVP).`):d&&f&&!o.includes(`LANL`)&&!o.includes(`SDD`)&&t.push(`Transition metals are present. Pople basis sets (like ${r.basisSet||`none`}) are often poor or unavailable. An ECP basis set (e.g., LanL2DZ or SDD) is recommended for transition metal centers.`);let m=s<0,h=c.includes(`TD`)||c.includes(`NSTATES`),g=o.includes(`+`)||o.startsWith(`AUG-`);m&&!g&&w(r.method)?t.push(`For systems with a negative charge (anions), adding diffuse functions (e.g., + in 6-31+G(d) or aug- in Dunning basis sets) is highly recommended to describe weakly bound electron density.`):h&&!g&&w(r.method)&&t.push(`For excited-state calculations (TD-DFT), adding diffuse functions (e.g., 6-31+G(d) or aug-cc-pVDZ) is recommended to properly capture diffuse excited state wavefunctions (Rydberg states).`),[`B3LYP`,`PBE`,`PBE0`,`OLYP`,`CAM-B3LYP`,`BLYP`,`BP86`].some(e=>a.includes(e))&&!l&&t.push(`Method ${r.method} is a DFT functional without dispersion correction. For geometries and non-covalent interactions, consider adding a dispersion correction (e.g., EmpiricalDispersion=GD3BJ).`);let _=[`MP2`,`MP3`,`MP4`,`CCSD`,`QCISD`].some(e=>a.includes(e)),v=o.includes(`3-21`)||o.includes(`6-31`)&&!o.includes(`6-311`)&&!o.includes(`+`)&&!o.includes(`D`);return _&&v&&t.push(`Electron correlation methods (like ${r.method}) converge very slowly with basis set size. Using small double-zeta basis sets (like ${r.basisSet||`none`}) is not recommended. Consider using cc-pVTZ or def2-TZVP.`),t}var te=class{constructor(e,t){this.container=e,this.onMoleculeChange=t,this.jsmeApplet=null,this.jsmeReady=!1,this.currentAtoms=[],this.currentMolfile=``,this.currentSmiles=``,this.charge=0,this.multiplicity=1,this.render(),this.bindEvents()}render(){this.container.innerHTML=`
      <!-- SMILES Input -->
      <div class="section animate-in">
        <div class="section-header" data-section="smiles-section">
          <div class="section-title" style="display: flex; align-items: center; gap: 4px;">
            <span class="section-icon">✏️</span>
            SMILES Input
            <span class="tooltip tooltip-bottom" data-tooltip="Convert standard text representation to 3D conformation" style="cursor: help; opacity: 0.6; font-size: 11px;">ℹ️</span>
          </div>
        </div>
        <div class="section-content" id="smiles-section">
          <div class="form-group">
            <div class="smiles-input-row">
              <input type="text" id="smiles-input" class="form-input" placeholder="e.g. c1ccccc1 (benzene)" autocomplete="off" spellcheck="false" />
              <button id="smiles-load-btn" class="btn btn-primary btn-sm">Load</button>
            </div>
            <div class="smiles-examples">
              <span class="form-label" style="margin-bottom: 4px; display: block;">Examples:</span>
              <div class="example-tags">
                <button class="btn btn-ghost btn-sm example-smiles" data-smiles="c1ccccc1">Benzene</button>
                <button class="btn btn-ghost btn-sm example-smiles" data-smiles="CC(=O)O">Acetic acid</button>
                <button class="btn btn-ghost btn-sm example-smiles" data-smiles="CCO">Ethanol</button>
                <button class="btn btn-ghost btn-sm example-smiles" data-smiles="C1CCCCC1">Cyclohexane</button>
                <button class="btn btn-ghost btn-sm example-smiles" data-smiles="O">Water</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- File Upload -->
      <div class="section animate-in" style="animation-delay: 0.05s">
        <div class="section-header" data-section="upload-section">
          <div class="section-title" style="display: flex; align-items: center; gap: 4px;">
            <span class="section-icon">📁</span>
            Import File
            <span class="tooltip tooltip-bottom" data-tooltip="Load external molecules directly from common files" style="cursor: help; opacity: 0.6; font-size: 11px;">ℹ️</span>
          </div>
        </div>
        <div class="section-content" id="upload-section">
          <div class="file-drop-zone" id="file-drop-zone">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="opacity:0.4">
              <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
            </svg>
            <p class="drop-text">Drop file or <label for="file-input" class="drop-link">browse</label></p>
            <p class="drop-formats">.cdxml · .mol · .sdf · .xyz · .gjf · .com</p>
            <input type="file" id="file-input" accept=".cdxml,.mol,.sdf,.xyz,.gjf,.com" hidden />
          </div>
          <div id="file-info" class="file-info hidden">
            <span id="file-name" class="file-name"></span>
            <button id="file-clear" class="btn btn-ghost btn-sm">✕</button>
          </div>
        </div>
      </div>

      <!-- 2D Editor (Disabled) -->

      <!-- Charge & Multiplicity -->
      <div class="section animate-in" style="animation-delay: 0.15s">
        <div class="section-header">
          <div class="section-title" style="display: flex; align-items: center; gap: 4px;">
            <span class="section-icon">⚡</span>
            Charge & Multiplicity
          </div>
        </div>
        <div class="section-content">
          <div class="charge-mult-row">
            <div class="form-group" style="flex:1">
              <label class="form-label" for="charge-input" style="display: flex; align-items: center; gap: 4px;">
                Charge
                <span class="tooltip" data-tooltip="Net electrical charge of the species" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
              </label>
              <input type="number" id="charge-input" class="form-input" value="0" min="-10" max="10" step="1" />
            </div>
            <div class="form-group" style="flex:1">
              <label class="form-label" for="mult-input" style="display: flex; align-items: center; gap: 4px;">
                Multiplicity
                <span class="tooltip" data-tooltip="Spin multiplicity (2S+1). Must match electron count parity." style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
              </label>
              <input type="number" id="mult-input" class="form-input" value="1" min="1" max="10" step="1" />
            </div>
          </div>
          <div id="charge-mult-warning" class="form-warning hidden"></div>
        </div>
      </div>

      <!-- Atom Count Info -->
      <div class="section animate-in" style="animation-delay: 0.2s">
        <div id="atom-info" class="atom-info">
          <span class="atom-info-text">No molecule loaded</span>
        </div>
      </div>
    `}bindEvents(){let e=this.container.querySelector(`#smiles-input`);this.container.querySelector(`#smiles-load-btn`).addEventListener(`click`,()=>this.loadSMILES()),e.addEventListener(`keydown`,e=>{e.key===`Enter`&&this.loadSMILES()}),this.container.querySelectorAll(`.example-smiles`).forEach(t=>{t.addEventListener(`click`,()=>{e.value=t.dataset.smiles,this.loadSMILES()})});let t=this.container.querySelector(`#file-input`),n=this.container.querySelector(`#file-drop-zone`),r=this.container.querySelector(`#file-clear`);t.addEventListener(`change`,e=>this.handleFileSelect(e.target.files[0])),n.addEventListener(`dragover`,e=>{e.preventDefault(),n.classList.add(`drag-over`)}),n.addEventListener(`dragleave`,()=>{n.classList.remove(`drag-over`)}),n.addEventListener(`drop`,e=>{e.preventDefault(),n.classList.remove(`drag-over`),e.dataTransfer.files.length&&this.handleFileSelect(e.dataTransfer.files[0])}),r.addEventListener(`click`,()=>{this.container.querySelector(`#file-info`).classList.add(`hidden`),this.container.querySelector(`#file-input`).value=``});let i=this.container.querySelector(`#charge-input`),a=this.container.querySelector(`#mult-input`);i.addEventListener(`change`,()=>{this.charge=parseInt(i.value)||0,this.notifyChange()}),a.addEventListener(`change`,()=>{this.multiplicity=parseInt(a.value)||1,this.notifyChange()})}initJSME(){let e=()=>{if(typeof JSApplet<`u`&&JSApplet.JSME!==void 0)try{this.jsmeApplet=new JSApplet.JSME(`jsme-container`,`100%`,`280px`,{options:`query,hydrogens,nocanonize,nostereo`}),this.jsmeReady=!0;let e=this.container.querySelector(`#jsme-loading`);e&&e.remove()}catch(e){console.warn(`JSME initialization failed:`,e);let t=this.container.querySelector(`#jsme-loading`);t&&(t.innerHTML=`<div class="viewer-placeholder"><span>JSME editor unavailable. Use SMILES or file import instead.</span></div>`)}else setTimeout(e,500)};setTimeout(e,1e3)}async loadSMILES(e=!1){let t=this.container.querySelector(`#smiles-input`).value.trim();if(t)try{let n=await b(t);if(this.currentAtoms=n.atoms,this.currentMolfile=n.molfile,this.currentSmiles=t,this.jsmeReady&&this.jsmeApplet)try{this.jsmeApplet.readMolFile(n.molfile)}catch{}this.updateAtomInfo(),this.notifyChange(),e||this.showToast(`Molecule loaded from SMILES`,`success`)}catch(t){e||this.showToast(`Invalid SMILES: ${t.message}`,`error`)}}async handleFileSelect(e){if(!e)return;let t=e.name.split(`.`).pop().toLowerCase(),n=await e.text();try{let r;switch(t){case`cdxml`:r=l(n);break;case`mol`:r=u(n);break;case`sdf`:r=d(n);break;case`xyz`:r=f(n);break;case`gjf`:case`com`:r=this.parseGJF(n);break;default:throw Error(`Unsupported file format: .${t}`)}if(r&&r.atoms&&r.atoms.length>0){this.currentAtoms=r.atoms,this.currentMolfile=r.molfile||``,this.currentSmiles=r.smiles||``,this.currentSmiles&&(this.container.querySelector(`#smiles-input`).value=this.currentSmiles);let t=this.container.querySelector(`#file-info`),n=this.container.querySelector(`#file-name`);if(n.textContent=`${e.name} (${r.atoms.length} atoms)`,t.classList.remove(`hidden`),this.jsmeReady&&this.jsmeApplet&&this.currentMolfile)try{this.jsmeApplet.readMolFile(this.currentMolfile)}catch{}r.charge!==void 0&&(this.charge=r.charge,this.container.querySelector(`#charge-input`).value=r.charge),r.multiplicity!==void 0&&(this.multiplicity=r.multiplicity,this.container.querySelector(`#mult-input`).value=r.multiplicity),this.updateAtomInfo(),this.notifyChange(),this.showToast(`Loaded ${r.atoms.length} atoms from ${e.name}`,`success`)}else throw Error(`No atoms found in file`)}catch(e){this.showToast(`Error parsing file: ${e.message}`,`error`)}}parseGJF(e){let t=e.split(`
`),n=[],r=0,i=1,a=!1,o=0,s=!1;for(let e=0;e<t.length;e++){let c=t[e].trim();if(!(c.startsWith(`%`)||c.startsWith(`#`))&&!c.startsWith(`!`)){if(c===``)s&&o++;else{if(s||c.startsWith(`%`)||c.startsWith(`#`)||(s=!0),s&&o>=2&&!a){let e=c.split(/\s+/);if(e.length>=2&&!isNaN(e[0])&&!isNaN(e[1])){r=parseInt(e[0]),i=parseInt(e[1]),a=!0;continue}}if(a){if(c===``||c.startsWith(`$`)||c.startsWith(`!`))break;let e=c.split(/\s+/);if(e.length>=4){let t=e[0].replace(/\d+$/,``),r=parseFloat(e[1]),i=parseFloat(e[2]),a=parseFloat(e[3]);isNaN(r)||isNaN(i)||isNaN(a)||n.push({symbol:t,x:r,y:i,z:a})}}}}}return{atoms:n,charge:r,multiplicity:i}}getFromEditor(){if(!this.jsmeReady||!this.jsmeApplet)this.showToast(`JSME editor not ready`,`warning`);else try{let e=this.jsmeApplet.smiles();if(!e||e.trim()===``){this.showToast(`Draw a molecule first`,`warning`);return}this.container.querySelector(`#smiles-input`).value=e,this.loadSMILES()}catch{this.showToast(`Could not read from editor`,`error`)}}updateAtomInfo(){let e=this.container.querySelector(`#atom-info`);if(this.currentAtoms.length===0){e.innerHTML=`<span class="atom-info-text">No molecule loaded</span>`;return}let t={};this.currentAtoms.forEach(e=>{t[e.symbol]=(t[e.symbol]||0)+1});let n=Object.entries(t).sort(([e],[t])=>e===`C`?-1:t===`C`?1:e===`H`?-1:t===`H`?1:e.localeCompare(t)).map(([e,t])=>`${e}${t>1?t:``}`).join(``);e.replaceChildren();let r=document.createElement(`div`);r.className=`atom-info-formula`,r.textContent=n;let i=document.createElement(`div`);i.className=`atom-info-count`,i.textContent=`${this.currentAtoms.length} atoms`,e.append(r,i)}notifyChange(){this.validateChargeMult(),this.onMoleculeChange&&this.onMoleculeChange({atoms:this.currentAtoms,molfile:this.currentMolfile,smiles:this.currentSmiles,charge:this.charge,multiplicity:this.multiplicity})}validateChargeMult(){let e=this.container.querySelector(`#charge-mult-warning`);if(!e)return;if(this.currentAtoms.length===0){e.classList.add(`hidden`);return}let t=T(this.charge,this.multiplicity,this.currentAtoms);if(t.valid)e.classList.add(`hidden`);else{let n=document.createElement(`span`);n.className=`warning-icon`,n.textContent=`⚠️`;let r=document.createElement(`span`);r.textContent=t.message,e.replaceChildren(n,r),e.classList.remove(`hidden`)}}showToast(e,t=`info`){if(t===`info`)return;let n=document.getElementById(`toast-container`);if(!n)return;let r=document.createElement(`div`);r.className=`toast toast-${t}`;let i=document.createElement(`span`);i.className=`toast-icon`,i.textContent=t===`success`?`✓`:t===`error`?`✕`:t===`warning`?`⚠`:`ℹ`;let a=document.createElement(`span`);a.className=`toast-message`,a.textContent=e,r.append(i,a),n.appendChild(r),setTimeout(()=>{r.classList.add(`toast-exit`),setTimeout(()=>r.remove(),300)},3e3)}setChargeMult(e,t){this.charge=e,this.multiplicity=t,this.container.querySelector(`#charge-input`).value=e,this.container.querySelector(`#mult-input`).value=t}getState(){return{atoms:this.currentAtoms,molfile:this.currentMolfile,smiles:this.currentSmiles,charge:this.charge,multiplicity:this.multiplicity}}},O=[{keyword:`BLYP`,name:`BLYP`,description:`Becke exchange + Lee-Yang-Parr correlation (pure GGA)`,category:`DFT`,subcategory:`GGA`,popular:!1,needsBasis:!0},{keyword:`BP86`,name:`BP86`,description:`Becke exchange + Perdew 86 correlation`,category:`DFT`,subcategory:`GGA`,popular:!1,needsBasis:!0},{keyword:`PBEPBE`,name:`PBE`,description:`Perdew-Burke-Ernzerhof exchange-correlation functional`,category:`DFT`,subcategory:`GGA`,popular:!1,needsBasis:!0},{keyword:`PW91PW91`,name:`PW91`,description:`Perdew-Wang 91 exchange-correlation functional`,category:`DFT`,subcategory:`GGA`,popular:!1,needsBasis:!0},{keyword:`TPSSTPSS`,name:`TPSS`,description:`Tao-Perdew-Staroverov-Scuseria meta-GGA functional`,category:`DFT`,subcategory:`Meta-GGA`,popular:!1,needsBasis:!0},{keyword:`M06L`,name:`M06-L`,description:`Minnesota 06 local functional (no HF exchange)`,category:`DFT`,subcategory:`Meta-GGA`,popular:!1,needsBasis:!0},{keyword:`B3LYP`,name:`B3LYP`,description:`Becke 3-parameter hybrid with LYP correlation — the most widely used DFT functional`,category:`DFT`,subcategory:`Hybrid`,popular:!0,needsBasis:!0},{keyword:`B3PW91`,name:`B3PW91`,description:`Becke 3-parameter hybrid with PW91 correlation`,category:`DFT`,subcategory:`Hybrid`,popular:!1,needsBasis:!0},{keyword:`PBE1PBE`,name:`PBE0`,description:`Hybrid PBE functional with 25% HF exchange`,category:`DFT`,subcategory:`Hybrid`,popular:!1,needsBasis:!0},{keyword:`BHandHLYP`,name:`BHandHLYP`,description:`Becke half-and-half hybrid with LYP correlation (50% HF exchange)`,category:`DFT`,subcategory:`Hybrid`,popular:!1,needsBasis:!0},{keyword:`O3LYP`,name:`O3LYP`,description:`OPTX exchange + LYP correlation hybrid functional`,category:`DFT`,subcategory:`Hybrid`,popular:!1,needsBasis:!0},{keyword:`X3LYP`,name:`X3LYP`,description:`Extended hybrid functional combining Becke and PW exchange with LYP correlation`,category:`DFT`,subcategory:`Hybrid`,popular:!1,needsBasis:!0},{keyword:`M05`,name:`M05`,description:`Minnesota 05 meta-hybrid functional`,category:`DFT`,subcategory:`Meta-Hybrid`,popular:!1,needsBasis:!0},{keyword:`M052X`,name:`M05-2X`,description:`Minnesota 05-2X with double HF exchange (56%)`,category:`DFT`,subcategory:`Meta-Hybrid`,popular:!1,needsBasis:!0},{keyword:`M06`,name:`M06`,description:`Minnesota 06 meta-hybrid — good for organometallics and thermochemistry`,category:`DFT`,subcategory:`Meta-Hybrid`,popular:!0,needsBasis:!0},{keyword:`M062X`,name:`M06-2X`,description:`Minnesota 06-2X with double HF exchange — excellent for main-group thermochemistry and kinetics`,category:`DFT`,subcategory:`Meta-Hybrid`,popular:!0,needsBasis:!0},{keyword:`M11`,name:`M11`,description:`Minnesota 11 range-separated meta-hybrid functional`,category:`DFT`,subcategory:`Meta-Hybrid`,popular:!1,needsBasis:!0},{keyword:`MN15`,name:`MN15`,description:`Minnesota 15 meta-hybrid — broad applicability across chemistry`,category:`DFT`,subcategory:`Meta-Hybrid`,popular:!1,needsBasis:!0},{keyword:`BMK`,name:`BMK`,description:`Boese-Martin kinetics functional — designed for barrier heights`,category:`DFT`,subcategory:`Meta-Hybrid`,popular:!1,needsBasis:!0},{keyword:`CAM-B3LYP`,name:`CAM-B3LYP`,description:`Coulomb-attenuating B3LYP — improved charge-transfer and excited states`,category:`DFT`,subcategory:`Range-Separated`,popular:!0,needsBasis:!0},{keyword:`wB97`,name:`ωB97`,description:`Long-range corrected functional by Head-Gordon`,category:`DFT`,subcategory:`Range-Separated`,popular:!1,needsBasis:!0},{keyword:`wB97X`,name:`ωB97X`,description:`ωB97 with short-range exact exchange`,category:`DFT`,subcategory:`Range-Separated`,popular:!1,needsBasis:!0},{keyword:`wB97XD`,name:`ωB97X-D`,description:`ωB97X with empirical dispersion — excellent general-purpose functional`,category:`DFT`,subcategory:`Range-Separated`,popular:!0,needsBasis:!0},{keyword:`LC-wPBE`,name:`LC-ωPBE`,description:`Long-range corrected PBE functional`,category:`DFT`,subcategory:`Range-Separated`,popular:!1,needsBasis:!0},{keyword:`B2PLYP`,name:`B2PLYP`,description:`Grimme double-hybrid with MP2 correlation`,category:`DFT`,subcategory:`Double Hybrid`,popular:!1,needsBasis:!0},{keyword:`B2PLYPD3`,name:`B2PLYP-D3`,description:`B2PLYP with D3 dispersion correction`,category:`DFT`,subcategory:`Double Hybrid`,popular:!1,needsBasis:!0},{keyword:`mPW2PLYP`,name:`mPW2PLYP`,description:`Modified Perdew-Wang double-hybrid functional`,category:`DFT`,subcategory:`Double Hybrid`,popular:!1,needsBasis:!0},{keyword:`DSDPBEP86`,name:`DSD-PBEP86`,description:`Dispersion-corrected, spin-component-scaled double hybrid`,category:`DFT`,subcategory:`Double Hybrid`,popular:!1,needsBasis:!0},{keyword:`APFD`,name:`APFD`,description:`Austin-Petersson-Frisch functional with built-in dispersion`,category:`DFT`,subcategory:`Dispersion-Included`,popular:!1,needsBasis:!0},{keyword:`B97D`,name:`B97-D`,description:`Grimme B97 with built-in dispersion correction`,category:`DFT`,subcategory:`Dispersion-Included`,popular:!1,needsBasis:!0},{keyword:`HF`,name:`Hartree-Fock`,description:`Hartree-Fock self-consistent field method — no electron correlation`,category:`Ab Initio`,subcategory:`Hartree-Fock`,popular:!0,needsBasis:!0},{keyword:`MP2`,name:`MP2`,description:`Second-order Møller-Plesset perturbation theory`,category:`Ab Initio`,subcategory:`Post-HF`,popular:!0,needsBasis:!0},{keyword:`MP3`,name:`MP3`,description:`Third-order Møller-Plesset perturbation theory`,category:`Ab Initio`,subcategory:`Post-HF`,popular:!1,needsBasis:!0},{keyword:`MP4`,name:`MP4`,description:`Fourth-order Møller-Plesset perturbation theory`,category:`Ab Initio`,subcategory:`Post-HF`,popular:!1,needsBasis:!0},{keyword:`CCSD`,name:`CCSD`,description:`Coupled-cluster singles and doubles`,category:`Ab Initio`,subcategory:`Post-HF`,popular:!1,needsBasis:!0},{keyword:`CCSD(T)`,name:`CCSD(T)`,description:`Coupled-cluster with perturbative triples — the "gold standard" of quantum chemistry`,category:`Ab Initio`,subcategory:`Post-HF`,popular:!0,needsBasis:!0},{keyword:`CISD`,name:`CISD`,description:`Configuration interaction singles and doubles`,category:`Ab Initio`,subcategory:`Post-HF`,popular:!1,needsBasis:!0},{keyword:`QCISD`,name:`QCISD`,description:`Quadratic configuration interaction singles and doubles`,category:`Ab Initio`,subcategory:`Post-HF`,popular:!1,needsBasis:!0},{keyword:`QCISD(T)`,name:`QCISD(T)`,description:`QCISD with perturbative triples correction`,category:`Ab Initio`,subcategory:`Post-HF`,popular:!1,needsBasis:!0},{keyword:`CASSCF`,name:`CASSCF`,description:`Complete active space self-consistent field — for multi-reference problems`,category:`Ab Initio`,subcategory:`Multi-Reference`,popular:!1,needsBasis:!0},{keyword:`CIS`,name:`CIS`,description:`Configuration interaction singles — simple excited-state method`,category:`Ab Initio`,subcategory:`Multi-Reference`,popular:!1,needsBasis:!0},{keyword:`SAC-CI`,name:`SAC-CI`,description:`Symmetry-adapted cluster configuration interaction for excited states`,category:`Ab Initio`,subcategory:`Multi-Reference`,popular:!1,needsBasis:!0},{keyword:`CBS-QB3`,name:`CBS-QB3`,description:`Complete basis set method — accurate thermochemistry at moderate cost`,category:`Composite`,subcategory:`CBS`,popular:!0,needsBasis:!1},{keyword:`CBS-4M`,name:`CBS-4M`,description:`CBS minimal basis set extrapolation — faster, less accurate than CBS-QB3`,category:`Composite`,subcategory:`CBS`,popular:!1,needsBasis:!1},{keyword:`CBS-APNO`,name:`CBS-APNO`,description:`CBS with atomic pair natural orbitals — highest accuracy CBS variant`,category:`Composite`,subcategory:`CBS`,popular:!1,needsBasis:!1},{keyword:`G3`,name:`G3`,description:`Gaussian-3 composite method for thermochemical predictions`,category:`Composite`,subcategory:`Gaussian-N`,popular:!1,needsBasis:!1},{keyword:`G3MP2`,name:`G3MP2`,description:`G3 with reduced MP2 treatment — faster alternative`,category:`Composite`,subcategory:`Gaussian-N`,popular:!1,needsBasis:!1},{keyword:`G3B3`,name:`G3B3`,description:`G3 using B3LYP geometries and zero-point energies`,category:`Composite`,subcategory:`Gaussian-N`,popular:!1,needsBasis:!1},{keyword:`G3MP2B3`,name:`G3MP2B3`,description:`G3MP2 using B3LYP geometries`,category:`Composite`,subcategory:`Gaussian-N`,popular:!1,needsBasis:!1},{keyword:`G4`,name:`G4`,description:`Gaussian-4 composite method — improved accuracy over G3`,category:`Composite`,subcategory:`Gaussian-N`,popular:!0,needsBasis:!1},{keyword:`G4MP2`,name:`G4MP2`,description:`G4 with reduced perturbation treatment — cost-effective thermochemistry`,category:`Composite`,subcategory:`Gaussian-N`,popular:!1,needsBasis:!1},{keyword:`W1BD`,name:`W1BD`,description:`Weizmann-1 with Brueckner doubles — sub-kcal/mol accuracy`,category:`Composite`,subcategory:`Weizmann`,popular:!1,needsBasis:!1},{keyword:`AM1`,name:`AM1`,description:`Austin Model 1 semi-empirical method`,category:`Semi-Empirical`,subcategory:`Semi-Empirical`,popular:!1,needsBasis:!1},{keyword:`PM3`,name:`PM3`,description:`Parameterized Model 3 semi-empirical method`,category:`Semi-Empirical`,subcategory:`Semi-Empirical`,popular:!1,needsBasis:!1},{keyword:`PM6`,name:`PM6`,description:`Parameterized Model 6 — improved semi-empirical method`,category:`Semi-Empirical`,subcategory:`Semi-Empirical`,popular:!1,needsBasis:!1},{keyword:`PM7`,name:`PM7`,description:`Parameterized Model 7 — latest in PM series`,category:`Semi-Empirical`,subcategory:`Semi-Empirical`,popular:!1,needsBasis:!1},{keyword:`MNDO`,name:`MNDO`,description:`Modified Neglect of Diatomic Overlap`,category:`Semi-Empirical`,subcategory:`Semi-Empirical`,popular:!1,needsBasis:!1},{keyword:`INDO`,name:`INDO`,description:`Intermediate Neglect of Differential Overlap`,category:`Semi-Empirical`,subcategory:`Semi-Empirical`,popular:!1,needsBasis:!1},{keyword:`UFF`,name:`UFF`,description:`Universal Force Field — covers entire periodic table`,category:`Molecular Mechanics`,subcategory:`Molecular Mechanics`,popular:!1,needsBasis:!1},{keyword:`AMBER`,name:`AMBER`,description:`Assisted Model Building with Energy Refinement — biomolecular force field`,category:`Molecular Mechanics`,subcategory:`Molecular Mechanics`,popular:!1,needsBasis:!1},{keyword:`DREIDING`,name:`DREIDING`,description:`DREIDING force field for organic and main-group molecules`,category:`Molecular Mechanics`,subcategory:`Molecular Mechanics`,popular:!1,needsBasis:!1}],k=[`DFT`,`Ab Initio`,`Composite`,`Semi-Empirical`,`Molecular Mechanics`],A=[{keyword:`STO-3G`,name:`STO-3G`,description:`Minimal basis set — 3 Gaussians per Slater orbital`,category:`Pople`,size:1,elements:`all`,popular:!1},{keyword:`3-21G`,name:`3-21G`,description:`Split-valence double-zeta basis without polarization`,category:`Pople`,size:2,elements:`all`,popular:!1},{keyword:`6-31G`,name:`6-31G`,description:`Split-valence double-zeta basis set`,category:`Pople`,size:2,elements:`all`,popular:!1},{keyword:`6-31G(d)`,name:`6-31G(d)`,description:`Double-zeta with d polarization on heavy atoms — workhorse basis`,category:`Pople`,size:2,elements:`all`,popular:!0},{keyword:`6-31G(d,p)`,name:`6-31G(d,p)`,description:`Double-zeta with polarization on heavy atoms and hydrogens`,category:`Pople`,size:2,elements:`all`,popular:!1},{keyword:`6-31+G(d)`,name:`6-31+G(d)`,description:`Double-zeta with diffuse functions on heavy atoms + d polarization`,category:`Pople`,size:3,elements:`all`,popular:!1},{keyword:`6-31+G(d,p)`,name:`6-31+G(d,p)`,description:`Double-zeta with diffuse and polarization on all atoms — great for anions`,category:`Pople`,size:3,elements:`all`,popular:!0},{keyword:`6-31++G(d,p)`,name:`6-31++G(d,p)`,description:`Double-zeta with diffuse functions on all atoms including hydrogens`,category:`Pople`,size:3,elements:`all`,popular:!1},{keyword:`6-311G(d,p)`,name:`6-311G(d,p)`,description:`Triple-zeta valence with polarization`,category:`Pople`,size:3,elements:`all`,popular:!1},{keyword:`6-311+G(d,p)`,name:`6-311+G(d,p)`,description:`Triple-zeta with diffuse and polarization — publication quality`,category:`Pople`,size:3,elements:`all`,popular:!0},{keyword:`6-311+G(2d,p)`,name:`6-311+G(2d,p)`,description:`Triple-zeta with extra d polarization on heavy atoms`,category:`Pople`,size:4,elements:`all`,popular:!1},{keyword:`6-311++G(d,p)`,name:`6-311++G(d,p)`,description:`Triple-zeta with full diffuse and polarization functions`,category:`Pople`,size:4,elements:`all`,popular:!1},{keyword:`6-311++G(2df,2pd)`,name:`6-311++G(2df,2pd)`,description:`Large triple-zeta with multiple polarization and full diffuse functions`,category:`Pople`,size:5,elements:`all`,popular:!1},{keyword:`6-311++G(3df,3pd)`,name:`6-311++G(3df,3pd)`,description:`Very large Pople basis — near basis set limit for this family`,category:`Pople`,size:5,elements:`all`,popular:!1},{keyword:`cc-pVDZ`,name:`cc-pVDZ`,description:`Correlation-consistent polarized valence double-zeta`,category:`Dunning`,size:2,elements:`all`,popular:!1},{keyword:`cc-pVTZ`,name:`cc-pVTZ`,description:`Correlation-consistent polarized valence triple-zeta`,category:`Dunning`,size:3,elements:`all`,popular:!0},{keyword:`cc-pVQZ`,name:`cc-pVQZ`,description:`Correlation-consistent polarized valence quadruple-zeta`,category:`Dunning`,size:4,elements:`all`,popular:!1},{keyword:`cc-pV5Z`,name:`cc-pV5Z`,description:`Correlation-consistent polarized valence quintuple-zeta`,category:`Dunning`,size:5,elements:`all`,popular:!1},{keyword:`aug-cc-pVDZ`,name:`aug-cc-pVDZ`,description:`Augmented cc-pVDZ with diffuse functions — good for anions`,category:`Dunning`,size:3,elements:`all`,popular:!1},{keyword:`aug-cc-pVTZ`,name:`aug-cc-pVTZ`,description:`Augmented cc-pVTZ — excellent for correlated methods and anions`,category:`Dunning`,size:4,elements:`all`,popular:!0},{keyword:`aug-cc-pVQZ`,name:`aug-cc-pVQZ`,description:`Augmented cc-pVQZ — near CBS limit for most properties`,category:`Dunning`,size:5,elements:`all`,popular:!1},{keyword:`aug-cc-pV5Z`,name:`aug-cc-pV5Z`,description:`Augmented cc-pV5Z — benchmark-quality basis set`,category:`Dunning`,size:5,elements:`all`,popular:!1},{keyword:`def2-SVP`,name:`def2-SVP`,description:`Karlsruhe split-valence polarized — efficient double-zeta`,category:`Karlsruhe`,size:2,elements:`all`,popular:!1},{keyword:`def2-TZVP`,name:`def2-TZVP`,description:`Karlsruhe triple-zeta valence polarized — excellent cost/accuracy ratio`,category:`Karlsruhe`,size:3,elements:`all`,popular:!0},{keyword:`def2-TZVPP`,name:`def2-TZVPP`,description:`Karlsruhe triple-zeta with extra polarization functions`,category:`Karlsruhe`,size:3,elements:`all`,popular:!1},{keyword:`def2-QZVP`,name:`def2-QZVP`,description:`Karlsruhe quadruple-zeta valence polarized`,category:`Karlsruhe`,size:4,elements:`all`,popular:!1},{keyword:`def2-QZVPP`,name:`def2-QZVPP`,description:`Karlsruhe quadruple-zeta with extra polarization — near CBS limit`,category:`Karlsruhe`,size:5,elements:`all`,popular:!1},{keyword:`LanL2DZ`,name:`LanL2DZ`,description:`Los Alamos ECP double-zeta — standard for transition metals`,category:`ECP`,size:2,elements:`heavy`,popular:!0},{keyword:`LanL2MB`,name:`LanL2MB`,description:`Los Alamos ECP minimal basis — fast screening of heavy elements`,category:`ECP`,size:1,elements:`heavy`,popular:!1},{keyword:`SDD`,name:`SDD`,description:`Stuttgart-Dresden ECP — recommended for heavy elements`,category:`ECP`,size:2,elements:`heavy`,popular:!0},{keyword:`SDDAll`,name:`SDDAll`,description:`Stuttgart-Dresden ECP applied to all atoms`,category:`ECP`,size:2,elements:`heavy`,popular:!1},{keyword:`CEP-31G`,name:`CEP-31G`,description:`Compact effective potential with split-valence basis`,category:`ECP`,size:2,elements:`heavy`,popular:!1},{keyword:`CEP-121G`,name:`CEP-121G`,description:`Compact effective potential with triple-split valence basis`,category:`ECP`,size:3,elements:`heavy`,popular:!1}],j=[`Pople`,`Dunning`,`Karlsruhe`,`ECP`],M=[{name:`Water`,keyword:`Water`,dielectric:78.3553,popular:!0},{name:`Methanol`,keyword:`Methanol`,dielectric:32.613,popular:!0},{name:`Ethanol`,keyword:`Ethanol`,dielectric:24.852,popular:!0},{name:`1-Propanol`,keyword:`n-Propanol`,dielectric:20.524,popular:!1},{name:`2-Propanol`,keyword:`IsoPropanol`,dielectric:19.264,popular:!1},{name:`1-Butanol`,keyword:`n-Butanol`,dielectric:17.332,popular:!1},{name:`Acetic Acid`,keyword:`AceticAcid`,dielectric:6.2528,popular:!1},{name:`Acetone`,keyword:`Acetone`,dielectric:20.493,popular:!0},{name:`Acetonitrile`,keyword:`Acetonitrile`,dielectric:35.688,popular:!0},{name:`Benzene`,keyword:`Benzene`,dielectric:2.2706,popular:!1},{name:`Carbon Tetrachloride`,keyword:`CarbonTetraChloride`,dielectric:2.228,popular:!1},{name:`Chloroform`,keyword:`Chloroform`,dielectric:4.7113,popular:!0},{name:`Cyclohexane`,keyword:`CycloHexane`,dielectric:2.0165,popular:!1},{name:`1,2-Dichloroethane`,keyword:`DiChloroEthane`,dielectric:10.125,popular:!1},{name:`Dichloromethane (DCM)`,keyword:`DiChloroMethane`,dielectric:8.93,popular:!0},{name:`Diethyl Ether`,keyword:`DiethylEther`,dielectric:4.24,popular:!0},{name:`N,N-Dimethylformamide (DMF)`,keyword:`DiMethylFormamide`,dielectric:37.219,popular:!0},{name:`Dimethyl Sulfoxide (DMSO)`,keyword:`DMSO`,dielectric:46.826,popular:!0},{name:`Ethyl Acetate`,keyword:`EthylAcetate`,dielectric:5.9867,popular:!1},{name:`Heptane`,keyword:`Heptane`,dielectric:1.9113,popular:!1},{name:`Hexane`,keyword:`n-Hexane`,dielectric:1.8819,popular:!0},{name:`Nitromethane`,keyword:`NitroMethane`,dielectric:36.562,popular:!1},{name:`Pentane`,keyword:`n-Pentane`,dielectric:1.8371,popular:!1},{name:`Pyridine`,keyword:`Pyridine`,dielectric:12.978,popular:!1},{name:`Tetrahydrofuran (THF)`,keyword:`THF`,dielectric:7.4257,popular:!0},{name:`Toluene`,keyword:`Toluene`,dielectric:2.3741,popular:!0},{name:`Xylenes`,keyword:`o-Xylene`,dielectric:2.5454,popular:!1},{name:`1,4-Dioxane`,keyword:`1,4-Dioxane`,dielectric:2.2099,popular:!1},{name:`Aniline`,keyword:`Aniline`,dielectric:6.8882,popular:!1},{name:`Formic Acid`,keyword:`MethanoicAcid`,dielectric:51.1,popular:!1}],ne=[{keyword:`PCM`,name:`PCM (Polarizable Continuum Model)`,description:`Default implicit solvation model in Gaussian`},{keyword:`SMD`,name:`SMD`,description:`Universal solvation model based on solute electron density (recommended)`}],N=[{keyword:`SP`,name:`Single Point Energy`,description:`Calculate energy at current geometry`,popular:!0},{keyword:`Opt`,name:`Geometry Optimization`,description:`Find minimum energy structure`,popular:!0},{keyword:`Opt Freq`,name:`Optimization + Frequency`,description:`Optimize then compute vibrational frequencies`,popular:!0},{keyword:`Freq`,name:`Frequency Analysis`,description:`Vibrational frequencies and thermochemistry`,popular:!0},{keyword:`Opt=(TS,CalcFC,NoEigenTest)`,name:`TS Optimization`,description:`Transition state search`,popular:!0},{keyword:`IRC=(CalcFC,MaxPoints=50)`,name:`IRC Path`,description:`Intrinsic reaction coordinate following`},{keyword:`Scan`,name:`PES Scan`,description:`Potential energy surface scan`},{keyword:`TD=(NStates=6)`,name:`TD-DFT (Excited States)`,description:`Time-dependent DFT for UV-Vis`,popular:!0},{keyword:`NMR`,name:`NMR Shielding`,description:`NMR chemical shift prediction`},{keyword:`Stable`,name:`Stability Analysis`,description:`Test wavefunction stability`},{keyword:`Polar`,name:`Polarizability`,description:`Polarizability and hyperpolarizability`},{keyword:`Force`,name:`Force Calculation`,description:`Compute forces/gradients`},{keyword:`Volume`,name:`Molecular Volume`,description:`Calculate molecular volume`}],re=[{keyword:``,name:`Default`,description:`Default SCF convergence`},{keyword:`SCF=Tight`,name:`Tight`,description:`Tighter convergence criteria`},{keyword:`SCF=(Tight,MaxCycle=200)`,name:`Tight + Max 200 cycles`,description:`Tight convergence with more iterations`},{keyword:`SCF=QC`,name:`Quadratically Convergent`,description:`For difficult convergence cases`},{keyword:`SCF=XQC`,name:`Extra QC`,description:`Fallback to QC if normal SCF fails`}],ie=[{keyword:``,name:`Default (UltraFine in G16)`,description:`Standard integration grid`},{keyword:`Int=UltraFine`,name:`UltraFine`,description:`Recommended for DFT (99,590)`},{keyword:`Int=SuperFine`,name:`SuperFine`,description:`Extra fine grid for difficult cases`},{keyword:`Int=FineGrid`,name:`Fine`,description:`Coarser grid (legacy)`}],ae=[{keyword:``,name:`None`,description:`No dispersion correction`},{keyword:`EmpiricalDispersion=GD3`,name:`GD3`,description:`Grimme's D3 dispersion`},{keyword:`EmpiricalDispersion=GD3BJ`,name:`GD3BJ`,description:`D3 with Becke-Johnson damping (recommended)`},{keyword:`EmpiricalDispersion=GD2`,name:`GD2`,description:`Grimme's D2 dispersion (older)`}],oe=[{keyword:``,name:`Default (Mulliken)`,description:`Standard Mulliken population`},{keyword:`Pop=Full`,name:`Full`,description:`Full population analysis with all MO coefficients`},{keyword:`Pop=NBO`,name:`NBO`,description:`Natural Bond Orbital analysis`},{keyword:`Pop=MK`,name:`Merz-Kollman`,description:`Merz-Kollman ESP charges`},{keyword:`Pop=CHELPG`,name:`CHELPG`,description:`CHELPG ESP charges`},{keyword:`Pop=NPA`,name:`NPA`,description:`Natural Population Analysis`}],se=[{prefix:`#N`,name:`Normal`,description:`Standard output`},{prefix:`#P`,name:`Verbose`,description:`Additional detail`},{prefix:`#T`,name:`Terse`,description:`Minimal output`}],ce=class{constructor(e,t){this.container=e,this.onParameterChange=t,this.state={memory:`4`,memoryUnit:`GB`,nproc:`4`,checkpoint:``,verbosity:`#N`,method:`B3LYP`,methodCategory:`DFT`,basisSet:`6-31G(d)`,basisSetCategory:`Pople`,jobType:`Opt Freq`,scf:``,grid:``,dispersion:``,pop:``,solvation:!1,solvationModel:`SMD`,solvent:`Water`,customKeywords:``,title:`Gaussian calculation`},this.hasHeavyAtoms=!1,this.render(),this.bindEvents()}getSelectedJobName(){let e=N.find(e=>e.keyword===this.state.jobType);return e?e.name:this.state.jobType||`Select calculation type`}render(){this.container.innerHTML=`
      <!-- Resources (Link 0) -->
      <div class="section animate-in">
        <div class="section-header collapsible" data-section="link0-content">
          <div class="section-title">
            <span class="section-icon">💻</span>
            Resources
          </div>
          <svg class="section-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </div>
        <div class="section-content" id="link0-content">
          <div class="form-row">
            <div class="form-group" style="flex:2">
              <label class="form-label" for="memory-input" style="display: flex; align-items: center; gap: 4px;">
                Memory
                <span class="tooltip" data-tooltip="Gaussian %Mem value (max RAM allocatable)" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
              </label>
              <div class="input-group">
                <input type="number" id="memory-input" class="form-input" value="${this.state.memory}" min="1" max="512" />
                <select id="memory-unit" class="form-select form-select-sm">
                  <option value="MB">MB</option>
                  <option value="GB" selected>GB</option>
                  <option value="TB">TB</option>
                </select>
              </div>
            </div>
            <div class="form-group" style="flex:1">
              <label class="form-label" for="nproc-input" style="display: flex; align-items: center; gap: 4px;">
                CPUs
                <span class="tooltip" data-tooltip="Gaussian %NProcShared value (number of CPU cores)" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
              </label>
              <input type="number" id="nproc-input" class="form-input" value="${this.state.nproc}" min="1" max="256" />
            </div>
          </div>
          <div class="form-group">
            <label class="form-label" for="chk-input" style="display: flex; align-items: center; gap: 4px;">
              Checkpoint file
              <span class="tooltip" data-tooltip="Gaussian %Chk filename for checkpoint recovery files" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
            </label>
            <input type="text" id="chk-input" class="form-input" value="${this.state.checkpoint}" placeholder="molecule.chk (optional)" />
          </div>
        </div>
      </div>

      <!-- Calculation Type -->
      <div class="section animate-in" style="animation-delay: 0.05s">
        <div class="section-header collapsible" data-section="job-content">
          <div class="section-title">
            <span class="section-icon">🎯</span>
            Calculation
          </div>
          <svg class="section-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </div>
        <div class="section-content" id="job-content">
          <div class="form-group">
            <label class="form-label" style="display: flex; align-items: center; gap: 4px;">
              Calculation Type
              <span class="tooltip" data-tooltip="Determines calculation type (e.g. geometry optimization vs. single point)" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
            </label>
            <div class="custom-select-wrap" id="job-select-wrap">
              <button type="button" class="custom-select-trigger" id="job-trigger">
                <span class="trigger-val">${this.getSelectedJobName()}</span>
                <svg class="trigger-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
              </button>
              <div class="custom-select-dropdown hidden" id="job-dropdown" style="background-color: #12151e !important; background: #12151e !important; opacity: 1 !important; z-index: 9999 !important;">
                <div class="dropdown-search-wrap">
                  <input type="text" class="form-input dropdown-search" id="job-search" placeholder="Search calculation types..." autocomplete="off" spellcheck="false" />
                </div>
                <div class="dropdown-list" id="job-list">
                  ${this.renderJobList()}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Method -->
      <div class="section animate-in" style="animation-delay: 0.1s">
        <div class="section-header collapsible" data-section="method-content">
          <div class="section-title">
            <span class="section-icon">🔬</span>
            Theory
          </div>
          <svg class="section-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </div>
        <div class="section-content" id="method-content">
          <div class="form-group">
            <label class="form-label" style="display: flex; align-items: center; gap: 4px;">
              Method / Level of Theory
              <span class="tooltip" data-tooltip="Theoretical model, density functional functional, or post-HF theory" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
            </label>
            <div class="custom-select-wrap" id="method-select-wrap">
              <button type="button" class="custom-select-trigger" id="method-trigger">
                <span class="trigger-val">
                  ${this.state.method}
                  <span class="trigger-val-badge">${this.state.methodCategory}</span>
                </span>
                <svg class="trigger-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
              </button>
              <div class="custom-select-dropdown hidden" id="method-dropdown" style="background-color: #12151e !important; background: #12151e !important; opacity: 1 !important; z-index: 9999 !important;">
                <div class="dropdown-tabs-search">
                  <div class="tab-bar compact" id="method-tabs">
                    ${k.map(e=>`
                      <button type="button" class="tab ${this.state.methodCategory===e?`active`:``}" data-method-cat="${e}">${e}</button>
                    `).join(``)}
                  </div>
                  <input type="text" class="form-input dropdown-search" id="method-search" placeholder="Search methods..." autocomplete="off" spellcheck="false" />
                </div>
                <div class="dropdown-list method-list-scrollable" id="method-list">
                  ${this.renderMethodList(this.state.methodCategory)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Basis Set -->
      <div class="section animate-in" style="animation-delay: 0.15s">
        <div class="section-header collapsible" data-section="basis-content">
          <div class="section-title">
            <span class="section-icon">📐</span>
            Basis Set
          </div>
          <svg class="section-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </div>
        <div class="section-content" id="basis-content">
          <div class="form-group">
            <label class="form-label" style="display: flex; align-items: center; gap: 4px;">
              Basis Set
              <span class="tooltip" data-tooltip="Mathematical functions representing molecular orbitals" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
            </label>
            <div class="custom-select-wrap" id="basis-select-wrap">
              <button type="button" class="custom-select-trigger" id="basis-trigger" ${this.state.basisSet===``?`disabled`:``}>
                <span class="trigger-val">
                  ${this.state.basisSet||`N/A`}
                  ${this.state.basisSet?`<span class="trigger-val-badge">${this.state.basisSetCategory}</span>`:``}
                </span>
                <svg class="trigger-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
              </button>
              <div class="custom-select-dropdown hidden" id="basis-dropdown" style="background-color: #12151e !important; background: #12151e !important; opacity: 1 !important; z-index: 9999 !important;">
                <div class="dropdown-tabs-search">
                  <div class="tab-bar compact" id="basis-tabs">
                    ${j.map(e=>`
                      <button type="button" class="tab ${this.state.basisSetCategory===e?`active`:``}" data-basis-cat="${e}">${e}</button>
                    `).join(``)}
                  </div>
                  <input type="text" class="form-input dropdown-search" id="basis-search" placeholder="Search basis sets..." autocomplete="off" spellcheck="false" />
                </div>
                <div class="dropdown-list basis-list-scrollable" id="basis-list">
                  ${this.renderBasisList(this.state.basisSetCategory)}
                </div>
              </div>
            </div>
            <div id="heavy-atom-notice" class="form-notice hidden" style="margin-top: 8px;">
              <span class="notice-icon">⚠️</span>
              <span>Heavy atoms detected. Consider using an <strong>ECP basis set</strong> (LanL2DZ, SDD) for transition metals.</span>
            </div>
          </div>
        </div>
      </div>


      <!-- Additional Options -->
      <div class="section animate-in" style="animation-delay: 0.2s">
        <div class="section-header collapsible" data-section="options-content">
          <div class="section-title">
            <span class="section-icon">🔧</span>
            Additional Options
          </div>
          <svg class="section-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </div>
        <div class="section-content" id="options-content">
          <div class="form-group">
            <label class="form-label" style="display: flex; align-items: center; gap: 4px;">
              Dispersion Correction
              <span class="tooltip" data-tooltip="Empirical dispersion models (e.g. D3, D3BJ) to model non-covalent forces" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
            </label>
            <select id="dispersion-select" class="form-select">
              ${ae.map(e=>`
                <option value="${e.keyword}" ${this.state.dispersion===e.keyword?`selected`:``}>${e.name}</option>
              `).join(``)}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" style="display: flex; align-items: center; gap: 4px;">
              SCF Convergence
              <span class="tooltip" data-tooltip="Self-Consistent Field convergence settings" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
            </label>
            <select id="scf-select" class="form-select">
              ${re.map(e=>`
                <option value="${e.keyword}" ${this.state.scf===e.keyword?`selected`:``}>${e.name}</option>
              `).join(``)}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" style="display: flex; align-items: center; gap: 4px;">
              Integration Grid
              <span class="tooltip" data-tooltip="Numerical integration grid density for DFT calculations" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
            </label>
            <select id="grid-select" class="form-select">
              ${ie.map(e=>`
                <option value="${e.keyword}" ${this.state.grid===e.keyword?`selected`:``}>${e.name}</option>
              `).join(``)}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" style="display: flex; align-items: center; gap: 4px;">
              Population Analysis
              <span class="tooltip" data-tooltip="Method to compute atomic charges & electrostatic properties" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
            </label>
            <select id="pop-select" class="form-select">
              ${oe.map(e=>`
                <option value="${e.keyword}" ${this.state.pop===e.keyword?`selected`:``}>${e.name}</option>
              `).join(``)}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" style="display: flex; align-items: center; gap: 4px;">
              Output Verbosity
              <span class="tooltip" data-tooltip="Volume of detail generated in the final Gaussian log output" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
            </label>
            <select id="verbosity-select" class="form-select">
              ${se.map(e=>`
                <option value="${e.prefix}" ${this.state.verbosity===e.prefix?`selected`:``}>${e.name} (${e.prefix})</option>
              `).join(``)}
            </select>
          </div>
        </div>
      </div>

      <!-- Solvation -->
      <div class="section animate-in" style="animation-delay: 0.25s">
        <div class="section-header collapsible" data-section="solv-content">
          <div class="section-title">
            <span class="section-icon">💧</span>
            Solvation
          </div>
          <svg class="section-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </div>
        <div class="section-content" id="solv-content">
          <div class="form-group">
            <label class="toggle-row" style="display: flex; align-items: center; gap: 6px; cursor: pointer;">
              <input type="checkbox" id="solvation-toggle" class="form-checkbox" ${this.state.solvation?`checked`:``} />
              <span class="toggle-label">Enable implicit solvation</span>
              <span class="tooltip" data-tooltip="Simulate solvent environments instead of gas phase" style="cursor: help; opacity: 0.6; font-size: 11px;">ℹ️</span>
            </label>
          </div>
          <div id="solvation-options" class="${this.state.solvation?``:`hidden`}">
            <div class="form-group">
              <label class="form-label">Solvation Model</label>
              <select id="solv-model-select" class="form-select">
                ${ne.map(e=>`
                  <option value="${e.keyword}" ${this.state.solvationModel===e.keyword?`selected`:``}>${e.name}</option>
                `).join(``)}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Solvent</label>
              <input type="text" id="solvent-search" class="form-input search-input" placeholder="Search solvents..." />
              <div class="solvent-list" id="solvent-list">
                ${this.renderSolventList()}
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Title & Custom -->
      <div class="section animate-in" style="animation-delay: 0.3s">
        <div class="section-header collapsible" data-section="title-content">
          <div class="section-title">
            <span class="section-icon">📝</span>
            Title & Custom
          </div>
          <svg class="section-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </div>
        <div class="section-content" id="title-content">
          <div class="form-group">
            <label class="form-label" for="title-input">Job Title</label>
            <input type="text" id="title-input" class="form-input" value="${this.state.title}" placeholder="Description of calculation" />
          </div>
          <div class="form-group">
            <label class="form-label" for="custom-keywords">Extra Keywords</label>
            <input type="text" id="custom-keywords" class="form-input" value="${this.state.customKeywords}" placeholder="e.g. NoSymm GFPrint" />
            <span class="form-hint">Added verbatim to the route section</span>
          </div>
        </div>
      </div>
    `,this.updateForAtoms(this.hasHeavyAtoms?[{symbol:`Sc`}]:[])}renderJobList(e=``){let t=N;if(e){let n=e.toLowerCase();t=N.filter(e=>e.name.toLowerCase().includes(n)||e.keyword.toLowerCase().includes(n))}return t.length===0?`<div class="list-empty">No matching job types found</div>`:t.map(e=>`
      <button type="button" class="dropdown-list-item ${this.state.jobType===e.keyword?`active`:``}" data-job="${e.keyword}" title="${e.description}">
        <div class="dropdown-item-meta">
          <span class="dropdown-item-title">${e.name}</span>
          <span class="dropdown-item-subtitle">${e.keyword}</span>
        </div>
        <div class="dropdown-item-desc">${e.description}</div>
      </button>
    `).join(``)}renderMethodList(e,t=``){let n=O.filter(t=>t.category===e);if(t){let r=t.toLowerCase();n=O.filter(t=>t.category===e&&(t.keyword.toLowerCase().includes(r)||t.name.toLowerCase().includes(r)))}if(n.length===0)return`<div class="list-empty">No methods found</div>`;let r={};return n.forEach(e=>{let t=e.subcategory||`General`;r[t]||(r[t]=[]),r[t].push(e)}),Object.entries(r).map(([e,t])=>`
      <div class="dropdown-list-group">
        <div class="dropdown-list-group-label">${e}</div>
        ${t.map(e=>`
          <button type="button" class="dropdown-list-item ${this.state.method===e.keyword?`active`:``}" 
                  data-method="${e.keyword}" title="${e.description||e.name}">
            <div class="dropdown-item-meta">
              <span class="dropdown-item-title">${e.keyword}</span>
              <span class="dropdown-item-subtitle">${e.name}</span>
            </div>
            ${e.popular?`<span class="badge badge-popular">★</span>`:``}
          </button>
        `).join(``)}
      </div>
    `).join(``)}renderBasisList(e,t=``){let n=A.filter(t=>t.category===e);if(t){let r=t.toLowerCase();n=A.filter(t=>t.category===e&&(t.keyword.toLowerCase().includes(r)||t.name.toLowerCase().includes(r)))}return n.length===0?`<div class="list-empty">No basis sets found</div>`:n.map(e=>`
      <button type="button" class="dropdown-list-item ${this.state.basisSet===e.keyword?`active`:``}" 
              data-basis="${e.keyword}" title="${e.description||e.name}">
        <div class="dropdown-item-meta">
          <span class="dropdown-item-title">${e.keyword}</span>
          <span class="dropdown-item-subtitle">${e.name}</span>
        </div>
        <div class="basis-meta-wrap">
          <span class="basis-size-bar">
            ${[,,,,,].fill(0).map((t,n)=>`<span class="size-dot ${n<e.size?`filled`:``}"></span>`).join(``)}
          </span>
          ${e.popular?`<span class="badge badge-popular">★</span>`:``}
        </div>
      </button>
    `).join(``)}renderSolventList(e=``){let t=M;if(e){let n=e.toLowerCase();t=M.filter(e=>e.name.toLowerCase().includes(n)||e.keyword.toLowerCase().includes(n))}let n=t.filter(e=>e.popular),r=t.filter(e=>!e.popular);return[...n,...r].map(e=>`
      <button type="button" class="list-item solvent-item ${this.state.solvent===e.keyword?`active`:``}"
              data-solvent="${e.keyword}">
        <span class="list-item-name">${e.name}</span>
        <span class="list-item-desc">ε=${e.dielectric}</span>
        ${e.popular?`<span class="badge badge-popular">★</span>`:``}
      </button>
    `).join(``)}setupDropdownToggle(e,t,n){let r=this.container.querySelector(e),i=this.container.querySelector(t),a=r?r.closest(`.custom-select-wrap`):null;r&&i&&a&&r.addEventListener(`click`,e=>{e.stopPropagation();let t=i.classList.contains(`hidden`);n.forEach(e=>{let t=this.container.querySelector(e),n=this.container.querySelector(e.replace(`-dropdown`,`-trigger`)),r=n?n.closest(`.custom-select-wrap`):null;t&&t.classList.add(`hidden`),n&&n.classList.remove(`active`),r&&r.classList.remove(`active`)}),t?(i.classList.remove(`hidden`),r.classList.add(`active`),a.classList.add(`active`)):(i.classList.add(`hidden`),r.classList.remove(`active`),a.classList.remove(`active`))})}bindEvents(){this.container.querySelectorAll(`.section-header.collapsible`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.section,n=this.container.querySelector(`#${t}`);n&&(n.classList.toggle(`collapsed`),e.classList.toggle(`collapsed`))})}),this.setupDropdownToggle(`#job-trigger`,`#job-dropdown`,[`#method-dropdown`,`#basis-dropdown`]),this.setupDropdownToggle(`#method-trigger`,`#method-dropdown`,[`#job-dropdown`,`#basis-dropdown`]),this.setupDropdownToggle(`#basis-trigger`,`#basis-dropdown`,[`#job-dropdown`,`#method-dropdown`]),document.addEventListener(`click`,e=>{[`job`,`method`,`basis`].forEach(t=>{let n=this.container.querySelector(`#${t}-dropdown`),r=this.container.querySelector(`#${t}-trigger`),i=r?r.closest(`.custom-select-wrap`):null;n&&!n.contains(e.target)&&r&&!r.contains(e.target)&&(n.classList.add(`hidden`),r&&r.classList.remove(`active`),i&&i.classList.remove(`active`))})}),this.bindJobClicks(),this.bindMethodClicks(),this.bindBasisClicks(),this.bindSolventClicks();let e=this.container.querySelector(`#job-search`);e&&(e.addEventListener(`click`,e=>e.stopPropagation()),e.addEventListener(`input`,()=>{let t=e.value.trim();this.container.querySelector(`#job-list`).innerHTML=this.renderJobList(t),this.bindJobClicks()}));let t=this.container.querySelector(`#method-search`);t&&(t.addEventListener(`click`,e=>e.stopPropagation()),t.addEventListener(`input`,()=>{let e=t.value.trim();this.container.querySelector(`#method-list`).innerHTML=this.renderMethodList(this.state.methodCategory,e),this.bindMethodClicks()}));let n=this.container.querySelector(`#basis-search`);n&&(n.addEventListener(`click`,e=>e.stopPropagation()),n.addEventListener(`input`,()=>{let e=n.value.trim();this.container.querySelector(`#basis-list`).innerHTML=this.renderBasisList(this.state.basisSetCategory,e),this.bindBasisClicks()})),this.container.querySelectorAll(`#method-tabs [data-method-cat]`).forEach(e=>{e.addEventListener(`click`,n=>{n.stopPropagation(),this.state.methodCategory=e.dataset.methodCat,this.container.querySelectorAll(`#method-tabs .tab`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),this.container.querySelector(`#method-list`).innerHTML=this.renderMethodList(this.state.methodCategory,t.value.trim()),this.bindMethodClicks()})}),this.container.querySelectorAll(`#basis-tabs [data-basis-cat]`).forEach(e=>{e.addEventListener(`click`,t=>{t.stopPropagation(),this.state.basisSetCategory=e.dataset.basisCat,this.container.querySelectorAll(`#basis-tabs .tab`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),this.container.querySelector(`#basis-list`).innerHTML=this.renderBasisList(this.state.basisSetCategory,n.value.trim()),this.bindBasisClicks()})});let r=this.container.querySelector(`#solvent-search`);r&&r.addEventListener(`input`,()=>{let e=r.value.trim();this.container.querySelector(`#solvent-list`).innerHTML=this.renderSolventList(e),this.bindSolventClicks()});let i=this.container.querySelector(`#solvation-toggle`);i&&i.addEventListener(`change`,()=>{this.state.solvation=i.checked;let e=this.container.querySelector(`#solvation-options`);e&&e.classList.toggle(`hidden`,!i.checked),this.notifyChange()}),this.bindSelect(`#dispersion-select`,`dispersion`),this.bindSelect(`#scf-select`,`scf`),this.bindSelect(`#grid-select`,`grid`),this.bindSelect(`#pop-select`,`pop`),this.bindSelect(`#verbosity-select`,`verbosity`),this.bindSelect(`#solv-model-select`,`solvationModel`),this.bindInput(`#memory-input`,`memory`),this.bindSelect(`#memory-unit`,`memoryUnit`),this.bindInput(`#nproc-input`,`nproc`),this.bindInput(`#chk-input`,`checkpoint`),this.bindInput(`#title-input`,`title`),this.bindInput(`#custom-keywords`,`customKeywords`)}bindSelect(e,t){let n=this.container.querySelector(e);n&&n.addEventListener(`change`,()=>{this.state[t]=n.value,this.notifyChange()})}bindInput(e,t){let n=this.container.querySelector(e);n&&n.addEventListener(`input`,()=>{this.state[t]=n.value,this.notifyChange()})}bindJobClicks(){this.container.querySelectorAll(`#job-list [data-job]`).forEach(e=>{e.addEventListener(`click`,t=>{t.stopPropagation(),this.state.jobType=e.dataset.job;let n=this.container.querySelector(`#job-dropdown`),r=this.container.querySelector(`#job-trigger`),i=r?r.closest(`.custom-select-wrap`):null;n&&n.classList.add(`hidden`),r&&(r.classList.remove(`active`),r.querySelector(`.trigger-val`).textContent=this.getSelectedJobName()),i&&i.classList.remove(`active`),this.container.querySelectorAll(`#job-list .dropdown-list-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),this.notifyChange()})})}bindMethodClicks(){this.container.querySelectorAll(`#method-list [data-method]`).forEach(e=>{e.addEventListener(`click`,t=>{t.stopPropagation(),this.state.method=e.dataset.method;let n=this.container.querySelector(`#method-dropdown`),r=this.container.querySelector(`#method-trigger`),i=r?r.closest(`.custom-select-wrap`):null;n&&n.classList.add(`hidden`),r&&(r.classList.remove(`active`),r.querySelector(`.trigger-val`).innerHTML=`
            ${this.state.method}
            <span class="trigger-val-badge">${this.state.methodCategory}</span>
          `),i&&i.classList.remove(`active`),this.container.querySelectorAll(`#method-list .dropdown-list-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`);let a=O.find(e=>e.keyword===this.state.method),o=this.container.querySelector(`#basis-trigger`);a&&a.needsBasis===!1?(this.state.basisSet=``,o&&(o.setAttribute(`disabled`,`true`),o.querySelector(`.trigger-val`).innerHTML=`N/A`)):o&&(o.removeAttribute(`disabled`),this.state.basisSet===``&&(this.state.basisSet=`6-31G(d)`,this.state.basisSetCategory=`Pople`),o.querySelector(`.trigger-val`).innerHTML=`
              ${this.state.basisSet}
              <span class="trigger-val-badge">${this.state.basisSetCategory}</span>
            `),this.notifyChange()})})}bindBasisClicks(){this.container.querySelectorAll(`#basis-list [data-basis]`).forEach(e=>{e.addEventListener(`click`,t=>{t.stopPropagation(),this.state.basisSet=e.dataset.basis;let n=this.container.querySelector(`#basis-dropdown`),r=this.container.querySelector(`#basis-trigger`),i=r?r.closest(`.custom-select-wrap`):null;n&&n.classList.add(`hidden`),r&&(r.classList.remove(`active`),r.querySelector(`.trigger-val`).innerHTML=`
            ${this.state.basisSet}
            <span class="trigger-val-badge">${this.state.basisSetCategory}</span>
          `),i&&i.classList.remove(`active`),this.container.querySelectorAll(`#basis-list .dropdown-list-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),this.notifyChange()})})}bindSolventClicks(){this.container.querySelectorAll(`#solvent-list [data-solvent]`).forEach(e=>{e.addEventListener(`click`,()=>{this.state.solvent=e.dataset.solvent,this.container.querySelectorAll(`#solvent-list .list-item`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),this.notifyChange()})})}notifyChange(){this.onParameterChange&&this.onParameterChange(this.getState())}updateForAtoms(e){let t=`Sc.Ti.V.Cr.Mn.Fe.Co.Ni.Cu.Zn.Y.Zr.Nb.Mo.Tc.Ru.Rh.Pd.Ag.Cd.Hf.Ta.W.Re.Os.Ir.Pt.Au.Hg.La.Ce.Pr.Nd.Pm.Sm.Eu.Gd.Tb.Dy.Ho.Er.Tm.Yb.Lu`.split(`.`);this.hasHeavyAtoms=e.some(e=>t.includes(e.symbol));let n=this.container.querySelector(`#heavy-atom-notice`);n&&n.classList.toggle(`hidden`,!this.hasHeavyAtoms)}applyPreset(e){let t=e.settings;t.method!==void 0&&(this.state.method=t.method),t.basisSet!==void 0&&(this.state.basisSet=t.basisSet),t.jobType!==void 0&&(this.state.jobType=t.jobType),t.dispersion!==void 0&&(this.state.dispersion=t.dispersion),t.scf!==void 0&&(this.state.scf=t.scf),t.grid!==void 0&&(this.state.grid=t.grid),t.solvation!==void 0&&(this.state.solvation=t.solvation),t.solvationModel!==void 0&&(this.state.solvationModel=t.solvationModel),t.solvent!==void 0&&(this.state.solvent=t.solvent),t.pop!==void 0&&(this.state.pop=t.pop);let n=O.find(e=>e.keyword===this.state.method);n&&(this.state.methodCategory=n.category);let r=A.find(e=>e.keyword===this.state.basisSet);r&&(this.state.basisSetCategory=r.category),this.render(),this.bindEvents(),this.notifyChange()}getState(){return{...this.state}}},le=new Set(`AM1.PM3.PM6.PM7.MNDO.MINDO3.INDO.CNDO.ZINDO.PDDG.RM1.UFF.DREIDING.AMBER.MM2.MM3.MM4.CBS-QB3.CBS-4M.CBS-APNO.G1.G2.G2MP2.G3.G3B3.G3MP2.G3MP2B3.G4.G4MP2.W1U.W1BD.W1RO.W2U.W2BD`.split(`.`));function P(e){if(!Number.isFinite(e))throw Error(`Atom coordinates must be finite numbers.`);return e.toFixed(6).padStart(12,` `)}function F(e){let t=(e.verbosity||`#N`).trim(),n=(e.method||``).trim();if(!n)throw Error(`A computational method is required to build the route section.`);let r=n.toUpperCase(),i=!le.has(r),a=(e.basisSet||``).trim(),o;o=i&&a?`${n}/${a}`:n;let s=[`jobType`,`scf`,`grid`,`dispersion`,`solvation`,`pop`,`custom`].map(t=>(e[t]||``).trim()).filter(e=>e.length>0);return[t,o,...s].join(` `)}function I(e){if(!e)throw Error(`Configuration object is required.`);if(!e.route||!e.route.method)throw Error(`Route section with a method is required.`);let t=Array.isArray(e.atoms)?e.atoms:[],n=[],r=e.link0||{};if(r.memory&&r.memory.trim()&&n.push(`%Mem=${r.memory.trim()}`),r.nproc!==void 0&&r.nproc!==null&&String(r.nproc).trim()&&n.push(`%NProcShared=${String(r.nproc).trim()}`),r.checkpoint&&r.checkpoint.trim()&&n.push(`%Chk=${r.checkpoint.trim()}`),r.other&&r.other.trim()){let e=r.other.trim().split(`
`).map(e=>e.trim()).filter(Boolean);for(let t of e)n.push(t.startsWith(`%`)?t:`%${t}`)}let i=F(e.route);n.push(i),n.push(``);let a=(e.title||`Gaussian calculation`).trim();n.push(a),n.push(``);let o=Number.isInteger(e.charge)?e.charge:0,s=Number.isInteger(e.multiplicity)&&e.multiplicity>=1?e.multiplicity:1;if(n.push(`${o} ${s}`),t.length>0)for(let e of t){let t=(e.symbol||`X`).padEnd(2,` `),r=P(e.x),i=P(e.y),a=P(e.z);n.push(` ${t}  ${r}${i}${a}`)}else n.push(` ! [Draw or import a structure to add coordinates here]`);return n.push(``),n.join(`
`)}var L=class{constructor(e,t=null){this.container=e,this.onAddToBatch=t,this.currentGJF=``,this.render()}render(){this.container.innerHTML=`
      <div class="code-preview">
        <div class="code-header">
          <span class="code-filename">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            output.gjf
          </span>
          <div class="code-actions" style="display: flex; gap: var(--space-2);">
            ${this.onAddToBatch?`
              <button id="preview-add-batch" class="btn btn-secondary btn-sm" title="Add to batch queue">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
                Add to Batch
              </button>
            `:``}
            <button id="preview-copy" class="btn btn-ghost btn-sm" title="Copy to clipboard">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
              Copy
            </button>
          </div>
        </div>
        <div id="gjf-warnings" class="code-warnings-container hidden"></div>
        <div class="code-body" id="gjf-code">
          <div class="code-placeholder">
            <span>Configure parameters and load a molecule to generate .gjf</span>
          </div>
        </div>
      </div>
    `,this.bindEvents()}bindEvents(){this.container.querySelector(`#preview-copy`).addEventListener(`click`,()=>this.copyToClipboard());let e=this.container.querySelector(`#preview-add-batch`);e&&this.onAddToBatch&&e.addEventListener(`click`,()=>this.onAddToBatch())}update(e,t){if(e)try{let n=this.buildConfig(e,t);this.currentGJF=I(n);let r=D(n),i=ee(n);this.renderCode(this.currentGJF,r,i)}catch(e){this.currentGJF=``;let t=this.container.querySelector(`#gjf-code`),n=this.container.querySelector(`#gjf-warnings`);n&&(n.classList.add(`hidden`),n.innerHTML=``),t&&(t.innerHTML=`<div class="code-placeholder error"><span>Error generating GJF: ${this.escapeHtml(e.message)}</span></div>`)}}buildConfig(e,t){let n=``;e.solvation&&e.solvent&&(n=`SCRF=(${e.solvationModel},Solvent=${e.solvent})`);let r=e.method||`HF`,i=e.basisSet||``;return{link0:{memory:e.memory?`${e.memory}${e.memoryUnit}`:``,nproc:e.nproc||``,checkpoint:e.checkpoint||``},route:{verbosity:e.verbosity||`#N`,method:r,basisSet:i,jobType:e.jobType||`SP`,scf:e.scf||``,grid:e.grid||``,dispersion:e.dispersion||``,solvation:n,pop:e.pop||``,custom:e.customKeywords||``},title:e.title||`Gaussian calculation`,charge:t?t.charge:0,multiplicity:t?t.multiplicity:1,atoms:t?t.atoms:[]}}renderCode(e,t,n=[]){let r=this.container.querySelector(`#gjf-code`),i=this.container.querySelector(`#gjf-warnings`);if(!e||e.trim()===``){r&&(r.innerHTML=`<div class="code-placeholder"><span>Configure parameters and load a molecule to generate .gjf</span></div>`),i&&(i.classList.add(`hidden`),i.innerHTML=``);return}let a=``;t&&!t.valid&&t.errors&&t.errors.length>0&&(a+=`
        <div class="form-warning" style="margin: 12px 16px 0 16px;">
          <div style="font-weight: 600; margin-bottom: 6px; display: flex; align-items: center; gap: 6px; color: var(--warning);">
            <span class="warning-icon">⚠️</span> Gaussian Input Verification Warnings
          </div>
          <ul style="margin: 0; padding-left: 18px; color: var(--text-secondary); font-size: 11px;">
            ${t.errors.map(e=>`<li style="margin-bottom: 2px;">${this.escapeHtml(e)}</li>`).join(``)}
          </ul>
        </div>
      `),n&&n.length>0&&(a+=`
        <div class="form-recommendation" style="margin: 12px 16px 0 16px; padding: 10px 12px; border-radius: var(--radius-md); border: 1px solid rgba(59, 130, 246, 0.2); background: rgba(59, 130, 246, 0.05);">
          <div style="font-weight: 600; margin-bottom: 6px; display: flex; align-items: center; gap: 6px; color: var(--info);">
            <span class="info-icon">💡</span> Theoretical Recommendations
          </div>
          <ul style="margin: 0; padding-left: 18px; color: var(--text-secondary); font-size: 11px; line-height: 1.4;">
            ${n.map(e=>`<li style="margin-bottom: 2px;">${this.escapeHtml(e)}</li>`).join(``)}
          </ul>
        </div>
      `),a?i&&(i.innerHTML=a,i.classList.remove(`hidden`)):i&&(i.classList.add(`hidden`),i.innerHTML=``),r.innerHTML=`<div class="code-lines">${e.split(`
`).map((e,t)=>`<div class="code-line">${`<span class="code-line-num">${String(t+1).padStart(3)}</span>`}<span class="code-line-content">${this.highlightLine(e)}</span></div>`).join(``)}</div>`}highlightLine(e){let t=this.escapeHtml(e);if(e.trim()===``)return`<span class="syn-blank">·</span>`;if(e.startsWith(`%`))return`<span class="syn-link0">${t}</span>`;if(e.startsWith(`#`))return this.highlightRoute(t);if(e.startsWith(`!`))return`<span class="syn-comment">${t}</span>`;if(e.trim().match(/^(-?\d+)\s+(\d+)$/))return`<span class="syn-charge">${t}</span>`;if(e.trim().match(/^([A-Z][a-z]?\d*)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)/)){let t=e.match(/^(\s*)(\S+)(\s+)(-?\d+\.\d+)(\s+)(-?\d+\.\d+)(\s+)(-?\d+\.\d+)/);if(t)return`${t[1]}<span class="syn-atom">${this.escapeHtml(t[2])}</span>${t[3]}<span class="syn-coord">${this.escapeHtml(t[4])}</span>${t[5]}<span class="syn-coord">${this.escapeHtml(t[6])}</span>${t[7]}<span class="syn-coord">${this.escapeHtml(t[8])}</span>`}return`<span class="syn-title">${t}</span>`}highlightRoute(e){let t=e;return t=t.replace(/^(#[NnPpTt]?)/,`<span class="syn-keyword">$1</span>`),t=t.replace(/([A-Za-z0-9\-\(\)]+\/[A-Za-z0-9\-\+\(\)\*,]+)/,`<span class="syn-route">$1</span>`),[`Opt`,`Freq`,`SP`,`IRC`,`Scan`,`TD`,`NMR`,`Stable`,`Polar`,`Force`,`Volume`,`Pop`,`SCRF`,`EmpiricalDispersion`,`SCF`,`Int`,`NoSymm`,`Symmetry`,`Guess`,`Geom`,`GFInput`,`GFPrint`,`MaxDisk`,`Counterpoise`,`Pseudo`].forEach(e=>{let n=RegExp(`\\b(${e}(?:=[^\\s]*)?)`,`gi`);t=t.replace(n,`<span class="syn-keyword">$1</span>`)}),t}escapeHtml(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}async copyToClipboard(){if(this.currentGJF)try{await navigator.clipboard.writeText(this.currentGJF),this.showToast(`Copied to clipboard`,`success`)}catch{let e=document.createElement(`textarea`);e.value=this.currentGJF,document.body.appendChild(e),e.select(),document.execCommand(`copy`),document.body.removeChild(e),this.showToast(`Copied to clipboard`,`success`)}}getGJF(){return this.currentGJF}showToast(e,t=`info`){if(t===`info`)return;let n=document.getElementById(`toast-container`);if(!n)return;let r=document.createElement(`div`);r.className=`toast toast-${t}`;let i=document.createElement(`span`);i.className=`toast-icon`,i.textContent=t===`success`?`✓`:`ℹ`;let a=document.createElement(`span`);a.className=`toast-message`,a.textContent=e,r.append(i,a),n.appendChild(r),setTimeout(()=>{r.classList.add(`toast-exit`),setTimeout(()=>r.remove(),300)},2e3)}},R=class{constructor(e){this.container=e,this.viewer=null,this.currentStyle=`stick`,this.render()}render(){this.container.innerHTML=`
      <div class="viewer-wrapper">
        <div class="viewer-container" id="viewer-3d">
          <div class="viewer-placeholder" id="viewer-placeholder">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" style="opacity:0.25">
              <circle cx="12" cy="12" r="3"/>
              <circle cx="5" cy="5" r="2"/>
              <circle cx="19" cy="5" r="2"/>
              <circle cx="5" cy="19" r="2"/>
              <circle cx="19" cy="19" r="2"/>
              <line x1="7" y1="7" x2="10" y2="10"/>
              <line x1="14" y1="10" x2="17" y2="7"/>
              <line x1="10" y1="14" x2="7" y2="17"/>
              <line x1="14" y1="14" x2="17" y2="17"/>
            </svg>
            <span>Load a molecule to view in 3D</span>
          </div>
        </div>
        <div class="viewer-controls">
          <button class="btn btn-ghost btn-icon btn-sm viewer-style-btn active" data-style="stick" title="Stick">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="19" x2="19" y2="5"/></svg>
          </button>
          <button class="btn btn-ghost btn-icon btn-sm viewer-style-btn" data-style="ballstick" title="Ball & Stick">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="7" cy="17" r="3"/><circle cx="17" cy="7" r="3"/><line x1="9" y1="15" x2="15" y2="9"/></svg>
          </button>
          <button class="btn btn-ghost btn-icon btn-sm viewer-style-btn" data-style="sphere" title="Spacefill">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/></svg>
          </button>
          <div class="viewer-divider"></div>
          <button class="btn btn-ghost btn-icon btn-sm" id="viewer-reset" title="Reset view">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
          </button>
        </div>
      </div>
    `,this.bindEvents()}bindEvents(){this.container.querySelectorAll(`.viewer-style-btn`).forEach(e=>{e.addEventListener(`click`,()=>{this.currentStyle=e.dataset.style,this.container.querySelectorAll(`.viewer-style-btn`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),this.applyStyle()})});let e=this.container.querySelector(`#viewer-reset`);e&&e.addEventListener(`click`,()=>{this.viewer&&(this.viewer.zoomTo(),this.viewer.render())})}initViewer(){if(typeof $3Dmol>`u`)return console.warn(`3Dmol.js not loaded yet`),!1;let e=this.container.querySelector(`#viewer-3d`);if(!e)return!1;let t=this.container.querySelector(`#viewer-placeholder`);if(t&&(t.style.display=`none`),this.viewer){let t=e.querySelector(`canvas`);t&&t.remove();let n=e.querySelector(`.viewer-canvas-container`);n&&n.remove()}try{return this.viewer=$3Dmol.createViewer(e,{backgroundColor:`0x0a0b10`,antialias:!0,disableFog:!0}),!0}catch(e){return console.error(`Failed to create 3Dmol viewer:`,e),!1}}updateMolecule(e,t=``){if(!e||e.length===0)this.pendingUpdate=null;else if(this.pendingUpdate={atoms:e,molfile:t},!this.viewer&&!this.initViewer()){if(!this.isPolling3Dmol){this.isPolling3Dmol=!0;let e=()=>{this.initViewer()?(this.isPolling3Dmol=!1,this.pendingUpdate&&this.updateMolecule(this.pendingUpdate.atoms,this.pendingUpdate.molfile)):setTimeout(e,150)};setTimeout(e,150)}}else{if(this.viewer.removeAllModels(),t)try{this.viewer.addModel(t,`mol`)}catch{this.addAtomsAsXYZ(e)}else this.addAtomsAsXYZ(e);this.applyStyle(),this.viewer.zoomTo(),this.viewer.render()}}addAtomsAsXYZ(e){let t=[e.length.toString(),`GaussianHelper molecule`,...e.map(e=>`${e.symbol} ${e.x.toFixed(6)} ${e.y.toFixed(6)} ${e.z.toFixed(6)}`)];this.viewer.addModel(t.join(`
`),`xyz`)}applyStyle(){if(this.viewer){switch(this.viewer.setStyle({},{}),this.currentStyle){case`stick`:this.viewer.setStyle({},{stick:{radius:.15,colorscheme:`Jmol`}});break;case`ballstick`:this.viewer.setStyle({},{stick:{radius:.12,colorscheme:`Jmol`},sphere:{scale:.25,colorscheme:`Jmol`}});break;case`sphere`:this.viewer.setStyle({},{sphere:{colorscheme:`Jmol`}})}this.viewer.render()}}},z=[{id:`quick-opt`,name:`Quick Optimization`,icon:`⚡`,description:`Fast geometry optimization for initial screening`,settings:{method:`B3LYP`,basisSet:`6-31G(d)`,jobType:`Opt`,dispersion:``,scf:``,grid:``,solvation:!1,pop:``}},{id:`accurate-opt`,name:`Accurate Optimization`,icon:`🎯`,description:`Publication-quality optimization with frequency check`,settings:{method:`M062X`,basisSet:`6-311+G(d,p)`,jobType:`Opt Freq`,dispersion:`EmpiricalDispersion=GD3BJ`,scf:`SCF=Tight`,grid:`Int=UltraFine`,solvation:!1,pop:``}},{id:`sp-energy`,name:`High-Accuracy Energy`,icon:`🔬`,description:`Gold-standard single point energy calculation`,settings:{method:`CCSD(T)`,basisSet:`cc-pVTZ`,jobType:`SP`,dispersion:``,scf:`SCF=Tight`,grid:``,solvation:!1,pop:``}},{id:`excited-states`,name:`Excited States (UV-Vis)`,icon:`🌈`,description:`TD-DFT for electronic excitation energies`,settings:{method:`CAM-B3LYP`,basisSet:`6-311+G(d,p)`,jobType:`TD=(NStates=6)`,dispersion:``,scf:``,grid:`Int=UltraFine`,solvation:!1,pop:``}},{id:`solvation`,name:`Solvation Study`,icon:`💧`,description:`Optimization with implicit solvation (SMD/Water)`,settings:{method:`M062X`,basisSet:`6-31+G(d,p)`,jobType:`Opt Freq`,dispersion:`EmpiricalDispersion=GD3BJ`,scf:`SCF=Tight`,grid:`Int=UltraFine`,solvation:!0,solvationModel:`SMD`,solvent:`Water`,pop:``}},{id:`ts-search`,name:`Transition State`,icon:`⛰️`,description:`Transition state optimization with frequency verification`,settings:{method:`B3LYP`,basisSet:`6-31+G(d,p)`,jobType:`Opt=(TS,CalcFC,NoEigenTest) Freq`,dispersion:`EmpiricalDispersion=GD3BJ`,scf:`SCF=Tight`,grid:`Int=UltraFine`,solvation:!1,pop:``}},{id:`nmr`,name:`NMR Prediction`,icon:`🧲`,description:`NMR chemical shift prediction`,settings:{method:`B3LYP`,basisSet:`6-311+G(2d,p)`,jobType:`NMR`,dispersion:``,scf:``,grid:``,solvation:!1,pop:``}},{id:`composite-g4`,name:`Composite G4`,icon:`🏆`,description:`Gaussian-4 composite method for high-accuracy thermochemistry`,settings:{method:`G4`,basisSet:``,jobType:``,dispersion:``,scf:``,grid:``,solvation:!1,pop:``}}],B=class{constructor({onPresetSelect:e,onCopy:t,onExport:n}){this.onPresetSelect=e,this.onCopy=t,this.onExport=n,this.presetBtn=document.getElementById(`preset-btn`),this.presetDropdown=document.getElementById(`preset-dropdown`),this.copyBtn=document.getElementById(`copy-btn`),this.exportBtn=document.getElementById(`export-btn`),this.init()}init(){this.renderPresets(),this.bindEvents()}renderPresets(){this.presetDropdown&&(this.presetDropdown.innerHTML=z.map(e=>`
      <div class="preset-card" data-preset-id="${e.id}" title="${e.description}">
        <div class="preset-icon">${e.icon}</div>
        <div class="preset-info">
          <div class="preset-name">${e.name}</div>
          <div class="preset-desc">${e.description}</div>
        </div>
      </div>
    `).join(``))}bindEvents(){this.presetBtn&&this.presetDropdown&&(this.presetBtn.addEventListener(`click`,e=>{e.stopPropagation(),this.presetDropdown.classList.toggle(`hidden`)}),document.addEventListener(`click`,e=>{!this.presetDropdown.contains(e.target)&&!this.presetBtn.contains(e.target)&&this.presetDropdown.classList.add(`hidden`)})),this.presetDropdown&&this.presetDropdown.addEventListener(`click`,e=>{let t=e.target.closest(`.preset-card`);if(t){let e=t.dataset.presetId,n=z.find(t=>t.id===e);n&&this.onPresetSelect&&this.onPresetSelect(n),this.presetDropdown.classList.add(`hidden`)}}),this.copyBtn&&this.copyBtn.addEventListener(`click`,()=>{this.onCopy&&this.onCopy()}),this.exportBtn&&this.exportBtn.addEventListener(`click`,()=>{this.onExport&&this.onExport()})}};function V(e){return`'${String(e).replace(/'/g,`'"'"'`)}'`}var H=class{constructor(e,t){this.container=e,this.getActiveJob=t,this.queue=[],this.format=`bcf`,this.startIndex=1,this.bcfComment=`Gaussian Batch Job`,this.linuxCmd=`g16`,this.render(),this.bindEvents()}render(){let e=this.generateScriptContent();this.container.innerHTML=`
      <div class="batch-generator animate-in">
        <!-- Settings Section -->
        <div class="card" style="margin-bottom: var(--space-4);">
          <div class="card-header">
            <span class="card-title">Batch Configuration</span>
          </div>
          <div class="card-body">
            <div class="form-row" style="display: flex; gap: var(--space-4); flex-wrap: wrap;">
              <div class="form-group" style="flex: 1; min-width: 200px;">
                <label class="form-label" style="display: flex; align-items: center; gap: 4px;">
                  Export Format
                  <span class="tooltip" data-tooltip="Switch script target between Windows Batch Control or Linux Bash shell" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
                </label>
                <div class="tab-bar compact" id="batch-format-selector" style="width: fit-content;">
                  <button type="button" class="tab ${this.format===`bcf`?`active`:``}" data-format="bcf">Windows (.bcf)</button>
                  <button type="button" class="tab ${this.format===`sh`?`active`:``}" data-format="sh">Linux (.sh)</button>
                </div>
              </div>

              ${this.format===`bcf`?`
                <div class="form-group" style="flex: 1; min-width: 100px;">
                  <label class="form-label" for="batch-start-index" style="display: flex; align-items: center; gap: 4px;">
                    Start Index
                    <span class="tooltip" data-tooltip="First execution job index (Gaussian BCF Start command)" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
                  </label>
                  <input type="number" id="batch-start-index" class="form-input" value="${this.startIndex}" min="1" />
                </div>
                <div class="form-group" style="flex: 2; min-width: 200px;">
                  <label class="form-label" for="batch-comment" style="display: flex; align-items: center; gap: 4px;">
                    Comment
                    <span class="tooltip" data-tooltip="Title comment line written inside the BCF file" style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
                  </label>
                  <input type="text" id="batch-comment" class="form-input" value="${this.escapeHtml(this.bcfComment)}" placeholder="e.g. Gaussian Batch Job" />
                </div>
              `:`
                <div class="form-group" style="flex: 2; min-width: 200px;">
                  <label class="form-label" for="batch-linux-cmd" style="display: flex; align-items: center; gap: 4px;">
                    Gaussian executable path
                    <span class="tooltip" data-tooltip="The path to one Gaussian executable (e.g. g16, g09, /usr/local/g16/g16). Do not include arguments." style="cursor: help; opacity: 0.6; font-size: 11px; text-transform: none;">ℹ️</span>
                  </label>
                  <input type="text" id="batch-linux-cmd" class="form-input" value="${this.escapeHtml(this.linuxCmd)}" placeholder="e.g. g16, g09, /usr/local/g16/g16" />
                </div>
              `}
            </div>
          </div>
        </div>

        <!-- Queue Section -->
        <div class="card" style="margin-bottom: var(--space-4);">
          <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
            <span class="card-title">Job Queue (${this.queue.length})</span>
            <div style="display: flex; gap: var(--space-2);">
              <button id="batch-add-current" class="btn btn-secondary btn-sm" title="Add the currently active GJF configuration to the queue">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
                Add Current Job
              </button>
              <button id="batch-upload-trigger" class="btn btn-secondary btn-sm" title="Upload existing GJF files from your computer to construct a batch control list">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                Upload GJFs
              </button>
              <input type="file" id="batch-file-input" multiple accept=".gjf" style="display: none;" />
            </div>
          </div>
          
          <div class="card-body" style="padding: 0; overflow-x: auto;">
            ${this.queue.length===0?`
              <div style="padding: var(--space-8); text-align: center; color: var(--text-tertiary);">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="margin: 0 auto var(--space-3) auto; opacity: 0.5;"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 17h6M9 12h6M9 7h6"/></svg>
                <div style="font-weight: 500; font-size: var(--text-base); color: var(--text-secondary); margin-bottom: var(--space-1);">Queue is empty</div>
                <div style="font-size: var(--text-xs);">Load a molecule and parameter settings to add it, or upload existing .gjf files to build a batch.</div>
              </div>
            `:`
              <table class="batch-table" style="width: 100%; border-collapse: collapse; text-align: left; font-size: var(--text-sm);">
                <thead>
                  <tr style="border-bottom: 1px solid var(--border-subtle); color: var(--text-secondary);">
                    <th style="padding: var(--space-3) var(--space-4); width: 50px;">#</th>
                    <th style="padding: var(--space-3) var(--space-4);">Input Filename (.gjf)</th>
                    <th style="padding: var(--space-3) var(--space-4);">Output Filename (.log)</th>
                    <th style="padding: var(--space-3) var(--space-4); width: 120px; text-align: right;">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  ${this.queue.map((e,t)=>`
                    <tr data-id="${e.id}" style="border-bottom: 1px solid var(--border-subtle); transition: background-color var(--transition-fast);">
                      <td style="padding: var(--space-3) var(--space-4); color: var(--text-tertiary); font-weight: 500;">${t+1}</td>
                      <td style="padding: var(--space-2) var(--space-4);">
                        <input type="text" class="form-input form-input-sm batch-input-filename" value="${this.escapeHtml(e.inputName)}" data-field="inputName" />
                      </td>
                      <td style="padding: var(--space-2) var(--space-4);">
                        <input type="text" class="form-input form-input-sm batch-output-filename" value="${this.escapeHtml(e.outputName)}" data-field="outputName" />
                      </td>
                      <td style="padding: var(--space-2) var(--space-4); text-align: right;">
                        <button class="btn btn-ghost btn-sm batch-btn-view" title="View GJF Code">👁️</button>
                        <button class="btn btn-ghost btn-sm btn-danger batch-btn-delete" title="Delete job">✕</button>
                      </td>
                    </tr>
                    <tr class="batch-gjf-preview-row hidden" data-preview-id="${e.id}" style="background: rgba(8, 9, 13, 0.4); border-bottom: 1px solid var(--border-subtle);">
                      <td colspan="4" style="padding: var(--space-3) var(--space-4);">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-2);">
                          <span style="font-weight: 600; color: var(--text-accent);">GJF Content Preview</span>
                          <button class="btn btn-secondary btn-sm batch-btn-close-view">Close Preview</button>
                        </div>
                        <pre style="margin: 0; padding: var(--space-3); background: var(--bg-input); border: 1px solid var(--border-primary); border-radius: var(--radius-md); font-family: var(--font-mono); font-size: var(--text-xs); overflow-x: auto; max-height: 250px; color: var(--text-primary); white-space: pre-wrap; word-break: break-all;">${this.escapeHtml(e.gjfText)}</pre>
                      </td>
                    </tr>
                  `).join(``)}
                </tbody>
              </table>
              <div style="padding: var(--space-3) var(--space-4); display: flex; justify-content: flex-end; border-top: 1px solid var(--border-subtle);">
                <button id="batch-clear-all" class="btn btn-danger btn-sm">Clear Queue</button>
              </div>
            `}
          </div>
        </div>

        <!-- Script Output Preview -->
        <div class="card">
          <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
            <span class="card-title">${this.format===`bcf`?`Batch Control File (.bcf)`:`Bash Script (.sh)`} Preview</span>
            <div style="display: flex; gap: var(--space-2);">
              <button id="batch-download-gjf-all" class="btn btn-secondary btn-sm" ${this.queue.length===0?`disabled`:``} title="Download all .gjf files in the queue">
                Download GJFs
              </button>
              <button id="batch-copy-script" class="btn btn-ghost btn-sm" ${this.queue.length===0?`disabled`:``}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
                Copy
              </button>
              <button id="batch-download-script" class="btn btn-primary btn-sm" ${this.queue.length===0?`disabled`:``}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                Download Script
              </button>
            </div>
          </div>
          <div class="card-body" style="padding: 0;">
            <div class="code-preview" style="border: none; border-radius: 0;">
              <div class="code-body" style="max-height: 300px;">
                <div class="code-content" style="padding: var(--space-4); font-size: var(--text-sm);">
                  ${this.queue.length===0?`
                    <div style="color: var(--text-tertiary); text-align: center; padding: var(--space-4);">
                      Preview will be generated here when calculations are added to the queue.
                    </div>
                  `:`
                    <code style="font-family: var(--font-mono); color: var(--text-primary); white-space: pre-wrap;">${this.escapeHtml(e)}</code>
                  `}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `}bindEvents(){this.container.querySelectorAll(`#batch-format-selector .tab`).forEach(e=>{e.addEventListener(`click`,()=>{this.format=e.dataset.format,this.render(),this.bindEvents()})});let e=this.container.querySelector(`#batch-start-index`);e&&e.addEventListener(`input`,e=>{this.startIndex=parseInt(e.target.value,10)||1,this.updatePreviewBlock()});let t=this.container.querySelector(`#batch-comment`);t&&t.addEventListener(`input`,e=>{this.bcfComment=e.target.value,this.updatePreviewBlock()});let n=this.container.querySelector(`#batch-linux-cmd`);n&&n.addEventListener(`input`,e=>{this.linuxCmd=e.target.value,this.updatePreviewBlock()});let r=this.container.querySelector(`#batch-add-current`);r&&r.addEventListener(`click`,()=>{this.addActiveJobToQueue()});let i=this.container.querySelector(`#batch-upload-trigger`),a=this.container.querySelector(`#batch-file-input`);i&&a&&(i.addEventListener(`click`,()=>{a.click()}),a.addEventListener(`change`,e=>{this.handleGJFUpload(e.target.files),a.value=``}));let o=this.container.querySelector(`#batch-clear-all`);o&&o.addEventListener(`click`,()=>{this.queue=[],this.render(),this.bindEvents(),this.showToast(`Batch queue cleared`,`info`)}),this.container.querySelectorAll(`.batch-table input`).forEach(e=>{e.addEventListener(`change`,e=>{let t=e.target.closest(`tr`).dataset.id,n=e.target.dataset.field,r=e.target.value.trim(),i=this.queue.find(e=>e.id===t);i&&r&&(i[n]=r,this.updatePreviewBlock())})}),this.container.querySelectorAll(`.batch-btn-delete`).forEach(e=>{e.addEventListener(`click`,e=>{let t=e.target.closest(`tr`).dataset.id;this.queue=this.queue.filter(e=>e.id!==t),this.render(),this.bindEvents()})}),this.container.querySelectorAll(`.batch-btn-view`).forEach(e=>{e.addEventListener(`click`,e=>{let t=e.target.closest(`tr`).dataset.id,n=this.container.querySelector(`tr[data-preview-id="${t}"]`);n&&n.classList.toggle(`hidden`)})}),this.container.querySelectorAll(`.batch-btn-close-view`).forEach(e=>{e.addEventListener(`click`,e=>{e.target.closest(`tr`).classList.add(`hidden`)})});let s=this.container.querySelector(`#batch-copy-script`);s&&s.addEventListener(`click`,()=>{let e=this.generateScriptContent();this.copyToClipboard(e)});let c=this.container.querySelector(`#batch-download-script`);c&&c.addEventListener(`click`,()=>{this.downloadScriptFile()});let l=this.container.querySelector(`#batch-download-gjf-all`);l&&l.addEventListener(`click`,()=>{this.downloadAllGJFFiles()})}addActiveJobToQueue(){let e=this.getActiveJob();if(!e||!e.gjfText||e.gjfText.trim()===``){this.showToast(`No active GJF. Please load a molecule and setup parameters.`,`warning`);return}let t=e.inputName||`calculation.gjf`,n=e.outputName||`calculation.log`,r=1,i=t,a=n;for(;this.queue.some(e=>e.inputName===i);){let e=t.lastIndexOf(`.`),o=e===-1?t:t.substring(0,e),s=e===-1?`.gjf`:t.substring(e);i=`${o}_${r}${s}`;let c=n.lastIndexOf(`.`),l=c===-1?n:n.substring(0,c),u=c===-1?`.log`:n.substring(c);a=`${l}_${r}${u}`,r++}let o={id:Date.now()+Math.random().toString(36).substring(2,9),inputName:i,outputName:a,gjfText:e.gjfText};this.queue.push(o),this.render(),this.bindEvents(),this.showToast(`Added ${i} to batch queue`,`success`)}handleGJFUpload(e){if(!e||e.length===0)return;let t=0,n=Array.from(e).map(e=>new Promise(n=>{let r=new FileReader;r.onload=r=>{let i=r.target.result,a=e.name,o=a.replace(/\.gjf$/i,``)+`.log`,s=a,c=o,l=1;for(;this.queue.some(e=>e.inputName===s);){let e=a.replace(/\.gjf$/i,``);s=`${e}_${l}.gjf`,c=`${e}_${l}.log`,l++}this.queue.push({id:Date.now()+Math.random().toString(36).substring(2,9)+t++,inputName:s,outputName:c,gjfText:i}),n()},r.readAsText(e)}));Promise.all(n).then(()=>{this.render(),this.bindEvents(),this.showToast(`Uploaded ${e.length} GJF file(s) into queue`,`success`)})}generateScriptContent(){if(this.queue.length===0)return``;if(this.format===`bcf`){let e=[];return this.bcfComment&&e.push(`! ${this.bcfComment}`),e.push(`Start=${this.startIndex}`),this.queue.forEach(t=>{e.push(`${t.inputName}, ${t.outputName}`)}),e.join(`\r
`)}{let e=[`#!/bin/bash`,`# Gaussian Batch Job Script`,`# Generated by GaussianHelper`,``,`# Check if the Gaussian command exists in path`,`GAUSSIAN_CMD=${V(this.linuxCmd)}`,`if ! command -v "$GAUSSIAN_CMD" &> /dev/null; then`,`    echo "Error: $GAUSSIAN_CMD could not be found. Please check your execution command or environment."`,`    exit 1`,`fi`,``,`echo "============================================="`,`echo "Starting Gaussian batch execution..."`,`echo "============================================="`,``];return this.queue.forEach((t,n)=>{let r=V(t.inputName),i=V(t.outputName);e.push(`printf '[Job ${n+1}/${this.queue.length}] Running %s < %s > %s\\n' "$GAUSSIAN_CMD" ${r} ${i}`),e.push(`"$GAUSSIAN_CMD" < ${r} > ${i}`),e.push(`if [ $? -eq 0 ]; then`),e.push(`    echo "✓ Job ${n+1} completed successfully"`),e.push(`else`),e.push(`    echo "❌ Error: Job ${n+1} failed. Continuing batch..."`),e.push(`fi`),e.push(``)}),e.push(`echo "============================================="`),e.push(`echo "Gaussian batch run finished."`),e.push(`echo "============================================="`),e.join(`
`)}}updatePreviewBlock(){let e=this.container.querySelector(`code`);e&&(e.textContent=this.generateScriptContent())}async copyToClipboard(e){if(e)try{await navigator.clipboard.writeText(e),this.showToast(`Copied to clipboard`,`success`)}catch{let t=document.createElement(`textarea`);t.value=e,document.body.appendChild(t),t.select(),document.execCommand(`copy`),document.body.removeChild(t),this.showToast(`Copied to clipboard`,`success`)}}downloadScriptFile(){let e=this.generateScriptContent();if(!e)return;let t=this.format===`bcf`,n=t?`gaussian_batch.bcf`:`gaussian_batch.sh`,r=new Blob([e],{type:`${t?`text/plain`:`application/x-sh`};charset=utf-8`}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=n,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(i),this.showToast(`Downloaded batch script as ${n}`,`success`)}downloadAllGJFFiles(){this.queue.length!==0&&(this.queue.forEach((e,t)=>{setTimeout(()=>{let t=new Blob([e.gjfText],{type:`text/plain;charset=utf-8`}),n=URL.createObjectURL(t),r=document.createElement(`a`);r.href=n,r.download=e.inputName,document.body.appendChild(r),r.click(),document.body.removeChild(r),URL.revokeObjectURL(n)},t*200)}),this.showToast(`Triggered download for ${this.queue.length} GJF file(s)`,`success`))}escapeHtml(e){return e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`)}showToast(e,t=`info`){if(t===`info`)return;let n=document.getElementById(`toast-container`);if(!n)return;let r=document.createElement(`div`);r.className=`toast toast-${t}`;let i=document.createElement(`span`);i.className=`toast-icon`,i.textContent=t===`success`?`✓`:t===`error`?`✕`:t===`warning`?`⚠`:`ℹ`;let a=document.createElement(`span`);a.className=`toast-message`,a.textContent=e,r.append(i,a),n.appendChild(r),setTimeout(()=>{r.classList.add(`toast-exit`),setTimeout(()=>r.remove(),300)},2e3)}},U=1048576,ue=30,de=300,fe=100,W=`[+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[EeDd][+-]?\\d+)?`,pe=RegExp(`\\bSCF Done:\\s*E\\(([^)]+)\\)\\s*=\\s*(${W})\\s*A\\.U\\b`,`i`),me=new RegExp(W,`g`);function G(e){return Number(e.replace(/[dD]/g,`E`))}function K(e){let t=e.trim();return t.length<=de?t:`${t.slice(0,299)}…`}function q(e){return{index:e,status:`incomplete`,termination:null,scf:{status:`unknown`,method:null,energyHartree:null,records:0,line:null,evidence:null},optimization:{status:`unknown`,line:null,evidence:null},frequencies:{count:0,imaginaryCount:0,imaginaryValues:[],omittedImaginaryValues:0,minImaginary:null,line:null,evidence:null,hasRecord:!1},diagnostics:[],omittedDiagnostics:0,hasContent:!1}}function J(e){return{index:e.index,status:e.status,termination:e.termination?{...e.termination}:null,scf:{...e.scf},optimization:{...e.optimization},frequencies:{count:e.frequencies.hasRecord?e.frequencies.count:null,imaginaryCount:e.frequencies.imaginaryCount,imaginaryValues:[...e.frequencies.imaginaryValues],omittedImaginaryValues:e.frequencies.omittedImaginaryValues,minImaginary:e.frequencies.minImaginary,line:e.frequencies.line,evidence:e.frequencies.evidence},diagnostics:e.diagnostics.map(e=>({...e})),omittedDiagnostics:e.omittedDiagnostics}}var Y=class{constructor(e=`output.log`){this.filename=e,this.sections=[],this.lineNumber=0,this.current=q(1),this.finishedResult=null}pushLine(e){if(this.finishedResult)throw Error(`Cannot add lines after the Gaussian log parser is finished.`);if(typeof e!=`string`)throw TypeError(`Gaussian log lines must be strings.`);if(e.length>U)throw Error(`Log line ${this.lineNumber+1} exceeds the 1 MiB safety limit.`);this.lineNumber++;let t=e.replace(/\0/g,``);t.trim()&&(this.current.hasContent=!0);let n=t.match(pe);if(n){let e=G(n[2]);Number.isFinite(e)&&(this.current.scf.status=`converged`,this.current.scf.method=n[1].trim(),this.current.scf.energyHartree=e,this.current.scf.records++,this.current.scf.line=this.lineNumber,this.current.scf.evidence=K(t))}else/\bSCF\s+(?:convergence\s+)?failure\b|\bSCF\s+has\s+not\s+converged\b/i.test(t)&&(this.current.scf.status=`failed`,this.current.scf.line=this.lineNumber,this.current.scf.evidence=K(t),this.addDiagnostic(`error`,t));/\b(?:Optimization completed|Stationary point found)\b/i.test(t)?this.current.optimization.status!==`converged`&&(this.current.optimization={status:`converged`,line:this.lineNumber,evidence:K(t)}):/\bOptimization (?:stopped|failed)\b|\bNumber of steps exceeded\b/i.test(t)&&(this.current.optimization={status:`not converged`,line:this.lineNumber,evidence:K(t)});let r=t.match(/\bFrequencies\s*--\s*(.*)$/i);if(r){let e=Array.from(r[1].matchAll(me),e=>G(e[0])).filter(Number.isFinite);this.current.frequencies.hasRecord=!0,this.current.frequencies.line=this.lineNumber,this.current.frequencies.evidence=K(t),this.current.frequencies.count+=e.length;for(let t of e)t<0&&(this.current.frequencies.imaginaryCount++,this.current.frequencies.imaginaryValues.length<fe?this.current.frequencies.imaginaryValues.push(t):this.current.frequencies.omittedImaginaryValues++,(this.current.frequencies.minImaginary===null||t<this.current.frequencies.minImaginary)&&(this.current.frequencies.minImaginary=t))}!/\bWarning\s+--\s+This program may not be used in any manner\b/i.test(t)&&/\b(?:Warning|Error|failed|failure|no convergence|not converged)\b/i.test(t)&&!n&&!/\bSCF\s+(?:convergence\s+)?failure\b|\bSCF\s+has\s+not\s+converged\b/i.test(t)&&this.addDiagnostic(/\b(?:Error|failed|failure)\b/i.test(t)?`error`:`warning`,t),/\bError termination\b/i.test(t)?this.closeSection(`error`,t):/\bNormal termination of Gaussian\b/i.test(t)&&this.closeSection(`completed`,t)}addDiagnostic(e,t){this.current.diagnostics.length>=ue?this.current.omittedDiagnostics++:this.current.diagnostics.push({kind:e,line:this.lineNumber,text:K(t)})}closeSection(e,t){this.current.status=e,this.current.termination={line:this.lineNumber,text:K(t)},this.sections.push(J(this.current)),this.current=q(this.sections.length+1)}finish(){if(this.finishedResult)return this.finishedResult;(this.current.hasContent||this.sections.length===0)&&this.sections.push(J(this.current));let e=this.sections.filter(e=>e.status===`completed`).length,t=this.sections.filter(e=>e.status===`error`).length,n=this.sections.filter(e=>e.status===`incomplete`).length,r=t>0?`error`:n>0?`incomplete`:`completed`;return this.finishedResult={filename:this.filename,sections:this.sections,summary:{status:r,completed:e,errors:t,incomplete:n}},this.finishedResult}};function he(e,t=`output.log`){if(typeof e!=`string`)throw TypeError(`Gaussian log content must be text.`);let n=new Y(t);for(let t of e.split(/\r\n|\n|\r/))n.pushLine(t);return n.finish()}async function ge(e,t=`output.log`){if(!e||typeof e.getReader!=`function`)throw TypeError(`A readable byte stream is required.`);let n=new Y(t),r=e.getReader(),i=new TextDecoder,a=``,o=(e,t=!1)=>{a+=e;let r=0,i=0;for(;i<a.length;){let e=a[i];if(e===`
`)n.pushLine(a.slice(r,i)),i++,r=i;else if(e===`\r`){if(i===a.length-1&&!t)break;n.pushLine(a.slice(r,i)),i+=a[i+1]===`
`?2:1,r=i}else i++;if(i-r>U)throw Error(`Log line ${n.lineNumber+1} exceeds the 1 MiB safety limit.`)}a=a.slice(r),t&&a.length>0&&(n.pushLine(a),a=``)};try{for(;;){let{value:e,done:t}=await r.read();if(t)break;o(i.decode(e,{stream:!0}))}return o(i.decode(),!0),n.finish()}finally{r.releaseLock()}}var _e=[`filename`,`section`,`status`,`termination_line`,`termination_text`,`scf_status`,`scf_method`,`scf_energy_hartree`,`scf_records`,`scf_line`,`scf_evidence`,`optimization_status`,`optimization_line`,`optimization_evidence`,`frequency_count`,`imaginary_count`,`most_negative_frequency_cm-1`,`imaginary_frequencies_cm-1`,`omitted_imaginary_values`,`frequency_line`,`frequency_evidence`,`diagnostics`];function X(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#39;`)}function Z(e){if(typeof e==`number`&&Number.isFinite(e))return String(e);let t=String(e??``);return/^\s*[=+\-@]/.test(t)&&(t=`'${t}`),`"${t.replace(/"/g,`""`)}"`}function Q(e){let t=[_e.map(Z).join(`,`)];for(let n of e)for(let e of n.sections||[]){let r=e.frequencies.count,i=(e.diagnostics||[]).map(e=>`${e.kind} (line ${e.line}): ${e.text}`).join(` | `),a=[n.filename,e.index,e.status,e.termination?.line??``,e.termination?.text??``,e.scf.status,e.scf.method??``,e.scf.energyHartree,e.scf.records,e.scf.line??``,e.scf.evidence??``,e.optimization.status,e.optimization.line??``,e.optimization.evidence??``,r,r===null?``:e.frequencies.imaginaryCount,e.frequencies.minImaginary,(e.frequencies.imaginaryValues||[]).join(`; `),e.frequencies.omittedImaginaryValues??0,e.frequencies.line??``,e.frequencies.evidence??``,i];t.push(a.map(Z).join(`,`))}return t.join(`\r
`)}function $(e){return{completed:`Completed`,error:`Error termination`,incomplete:`Incomplete`,"parse-error":`Could not read`}[e]||`Unknown`}function ve(e){let t=e.frequencies;if(t.count===null)return`Not found`;let n=t.imaginaryCount===1?`1 negative mode`:`${t.imaginaryCount} negative modes`,r=t.minImaginary===null?``:` · most negative ${t.minImaginary} cm⁻¹`,i=t.line?` · line ${t.line}`:``;return`${t.count} modes · ${n}${r}${i}`}function ye(e){return Number.isFinite(e)?`${e} Hartree`:`Not found`}var be=class{constructor(e){this.container=e,this.results=[],this.processing=!1,this.statusMessage=`Files are parsed locally in this browser; no log contents are uploaded or saved.`,this.render()}render(){let e=this.results.reduce((e,t)=>e+(t.sections?.length||0),0),t=this.results.reduce((e,t)=>e+(t.summary?.completed||0),0),n=this.results.reduce((e,t)=>e+(t.summary?.errors||0),0),r=this.results.reduce((e,t)=>e+(t.summary?.incomplete||0),0),i=this.results.filter(e=>e.parseError).length;this.container.innerHTML=`
      <div class="gaussian-output-inspector">
        <section class="card">
          <div class="card-header">
            <span class="card-title">Gaussian Output Inspector</span>
            <div class="inspector-actions">
              <button id="inspector-export-csv" class="btn btn-secondary btn-sm" ${e===0?`disabled`:``}>Export CSV</button>
              <button id="inspector-clear" class="btn btn-ghost btn-sm" ${this.results.length===0||this.processing?`disabled`:``}>Clear</button>
            </div>
          </div>
          <div class="card-body">
            <label class="file-drop-zone gaussian-log-dropzone" id="gaussian-log-dropzone">
              <span class="file-drop-zone-icon" aria-hidden="true">📄</span>
              <span class="file-drop-zone-text">Drop Gaussian output files here or browse</span>
              <span class="file-drop-zone-hint">Select one or more .log / .out files</span>
              <input id="gaussian-log-input" type="file" accept=".log,.out" multiple ${this.processing?`disabled`:``} hidden />
            </label>
            <div class="inspector-status" id="inspector-status" role="status" aria-live="polite">${X(this.statusMessage)}</div>
          </div>
        </section>

        ${e||i?`
          <div class="inspector-summary" aria-label="Batch summary">
            <div class="inspector-summary-item"><strong>${e}</strong><span>Sections</span></div>
            <div class="inspector-summary-item"><strong>${t}</strong><span>Completed</span></div>
            <div class="inspector-summary-item"><strong>${n+i}</strong><span>Errors</span></div>
            <div class="inspector-summary-item"><strong>${r}</strong><span>Incomplete</span></div>
          </div>
        `:``}

        <div class="inspector-results">
          ${this.results.length===0?``:this.results.map(e=>this.renderFileResult(e)).join(``)}
        </div>
      </div>
    `,this.bindEvents()}bindEvents(){let e=this.container.querySelector(`#gaussian-log-input`),t=this.container.querySelector(`#gaussian-log-dropzone`),n=this.container.querySelector(`#inspector-export-csv`),r=this.container.querySelector(`#inspector-clear`);e?.addEventListener(`change`,e=>{let t=Array.from(e.target.files||[]);e.target.value=``,this.processFiles(t)}),t?.addEventListener(`dragover`,e=>{e.preventDefault(),t.classList.add(`dragover`)}),t?.addEventListener(`dragleave`,()=>t.classList.remove(`dragover`)),t?.addEventListener(`drop`,e=>{e.preventDefault(),t.classList.remove(`dragover`),this.processFiles(Array.from(e.dataTransfer?.files||[]))}),n?.addEventListener(`click`,()=>this.downloadCsv()),r?.addEventListener(`click`,()=>{this.results=[],this.statusMessage=`Results cleared. Files are parsed locally in this browser.`,this.render()})}async processFiles(e){if(!(this.processing||e.length===0)){this.processing=!0,this.statusMessage=`Processing ${e.length} file(s)…`,this.render();try{for(let t=0;t<e.length;t++){let n=e[t];try{if(!/\.(?:log|out)$/i.test(n.name))throw Error(`Only .log and .out files are supported.`);let e=typeof n.stream==`function`?await ge(n.stream(),n.name):he(await n.text(),n.name);e.sizeBytes=n.size,this.results.push(e)}catch(e){this.results.push({filename:n.name,sizeBytes:n.size,parseError:e instanceof Error?e.message:String(e),sections:[],summary:{status:`parse-error`,completed:0,errors:0,incomplete:0}})}this.statusMessage=`Processed ${t+1} of ${e.length} file(s). Logs remain on this device.`,this.render()}this.statusMessage=`Finished processing ${e.length} file(s). Results are only held in this page.`}finally{this.processing=!1,this.render()}}}renderFileResult(e){let t=Number.isFinite(e.sizeBytes)?` · ${xe(e.sizeBytes)}`:``;if(e.parseError)return`
        <section class="card inspector-file-result">
          <div class="card-header">
            <span class="inspector-file-name">${X(e.filename)}${t}</span>
            <span class="inspector-status-badge status-error">${$(`parse-error`)}</span>
          </div>
          <div class="card-body"><div class="form-warning">${X(e.parseError)}</div></div>
        </section>
      `;let n=e.summary;return`
      <section class="card inspector-file-result">
        <div class="card-header">
          <span class="inspector-file-name">${X(e.filename)}${t}</span>
          <span class="inspector-status-badge status-${X(n.status)}">${$(n.status)}</span>
        </div>
        <div class="card-body">
          <div class="inspector-file-summary">${n.completed} completed · ${n.errors} errors · ${n.incomplete} incomplete section(s)</div>
          ${e.sections.map(e=>this.renderSection(e)).join(``)}
        </div>
      </section>
    `}renderSection(e){let t=ye(e.scf.energyHartree),n=e.scf.evidence?`<details class="inspector-evidence"><summary>SCF source, line ${e.scf.line}</summary><code>${X(e.scf.evidence)}</code></details>`:``,r=e.optimization.evidence?`<details class="inspector-evidence"><summary>Optimization source, line ${e.optimization.line}</summary><code>${X(e.optimization.evidence)}</code></details>`:``,i=e.frequencies.evidence?`<details class="inspector-evidence"><summary>Frequency source, line ${e.frequencies.line}</summary><code>${X(e.frequencies.evidence)}</code></details>`:``,a=e.termination?`<div><strong>Termination:</strong> line ${e.termination.line} — <code>${X(e.termination.text)}</code></div>`:`<div><strong>Termination:</strong> no termination marker found</div>`,o=e.frequencies.imaginaryValues||[],s=o.length?` · values ${o.join(`, `)} cm⁻¹${e.frequencies.omittedImaginaryValues?` (first ${o.length} shown; ${e.frequencies.omittedImaginaryValues} omitted)`:``}`:``,c=e.diagnostics.length?`<details class="inspector-diagnostics"><summary>Warnings / errors (${e.diagnostics.length}${e.omittedDiagnostics?` shown, ${e.omittedDiagnostics} omitted`:``})</summary><ul>${e.diagnostics.map(e=>`<li><strong>${X(e.kind)} · line ${e.line}:</strong> <code>${X(e.text)}</code></li>`).join(``)}</ul></details>`:`<div class="inspector-no-diagnostics">No matching warning/error lines found; this is not a correctness guarantee.</div>`;return`
      <details class="inspector-section" open>
        <summary>Section ${e.index} · ${$(e.status)}</summary>
        <div class="inspector-metrics">
          <div><strong>SCF:</strong> ${X(e.scf.status)} · ${X(e.scf.method||`method not found`)} · ${X(t)}${e.scf.line?` · line ${e.scf.line}`:``}</div>
          <div><strong>Optimization:</strong> ${X(e.optimization.status)}${e.optimization.line?` · line ${e.optimization.line}`:``}</div>
          <div><strong>Frequencies:</strong> ${X(ve(e))}${X(s)}</div>
          ${a}
        </div>
        ${n}${r}${i}${c}
      </details>
    `}downloadCsv(){let e=Q(this.results);if(!e||this.results.every(e=>e.sections.length===0))return;let t=new Blob([e],{type:`text/csv;charset=utf-8`}),n=URL.createObjectURL(t),r=document.createElement(`a`);r.href=n,r.download=`gaussian-output-summary.csv`,document.body.appendChild(r),r.click(),r.remove(),setTimeout(()=>URL.revokeObjectURL(n),1e3)}};function xe(e){return e<1024?`${e} B`:e<1048576?`${(e/1024).toFixed(1)} KB`:`${(e/1048576).toFixed(1)} MB`}document.addEventListener(`DOMContentLoaded`,()=>{let e=document.getElementById(`molecule-panel`),t=document.getElementById(`parameter-panel`),n=document.getElementById(`output-panel`);if(!e||!t||!n){console.error(`Core UI containers not found`);return}n.innerHTML=`
    <div class="tab-bar" id="output-tabs" style="margin-bottom: var(--space-4);">
      <button type="button" class="tab active" data-output-tab="calc">Current Job</button>
      <button type="button" class="tab" data-output-tab="batch">Batch Queue</button>
      <button type="button" class="tab" data-output-tab="inspector">Output Inspector</button>
    </div>
    <div id="calc-tab-content" class="tab-panel-content animate-in">
      <div id="viewer-container-target" class="animate-in"></div>
      <div id="preview-container-target" class="animate-in" style="animation-delay: 0.05s; margin-top: var(--space-4);"></div>
    </div>
    <div id="batch-tab-content" class="tab-panel-content hidden animate-in"></div>
    <div id="inspector-tab-content" class="tab-panel-content hidden animate-in"><div id="inspector-container-target"></div></div>
  `;let r=document.getElementById(`viewer-container-target`),i=document.getElementById(`preview-container-target`),o=document.getElementById(`batch-tab-content`),s=document.getElementById(`inspector-container-target`),c=new R(r),l=n.querySelectorAll(`#output-tabs .tab`),u=document.getElementById(`calc-tab-content`),d=document.getElementById(`batch-tab-content`),f=document.getElementById(`inspector-tab-content`);function p(e){l.forEach(t=>t.classList.toggle(`active`,t.dataset.outputTab===e)),u.classList.toggle(`hidden`,e!==`calc`),d.classList.toggle(`hidden`,e!==`batch`),f.classList.toggle(`hidden`,e!==`inspector`),e===`calc`&&c?.viewer&&(c.viewer.zoomTo(),c.viewer.render())}let m=()=>p(`batch`);l.forEach(e=>{e.addEventListener(`click`,()=>p(e.dataset.outputTab))});let h,g=new L(i,()=>{h&&(h.addActiveJobToQueue(),m())}),_=new ce(t,e=>{let t=v.getState();g.update(e,t)}),v=new te(e,e=>{_.updateForAtoms(e.atoms),c.updateMolecule(e.atoms,e.molfile);let t=_.getState();g.update(t,e)});h=new H(o,()=>{let e=_.getState(),t=v.getState(),n=g.getGJF(),r=`gaussian_input`;return e.checkpoint?r=e.checkpoint.replace(/\.chk$/,``):t.atoms&&t.atoms.length>0&&(r=a(t.atoms).toLowerCase()),{gjfText:n,inputName:`${r}.gjf`,outputName:`${r}.log`}}),new be(s);let y=document.getElementById(`smiles-input`);y&&(y.value=`O`,v.loadSMILES(!0)),new B({onPresetSelect:e=>{_.applyPreset(e),w(`Loaded preset: ${e.name}`,`success`)},onCopy:()=>{g.copyToClipboard()},onExport:()=>{let e=g.getGJF();if(!e||e.trim()===``){w(`Draw/load a molecule to export GJF file`,`warning`);return}let t=_.getState(),n=v.getState(),r=`gaussian_input.gjf`;t.checkpoint?r=t.checkpoint.replace(/\.chk$/,``)+`.gjf`:n.atoms&&n.atoms.length>0&&(r=`${a(n.atoms).toLowerCase()}.gjf`);let i=new Blob([e],{type:`text/plain;charset=utf-8`}),o=URL.createObjectURL(i),s=document.createElement(`a`);s.href=o,s.download=r,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(o),w(`Exported GJF as ${r}`,`success`)}});let b=document.getElementById(`help-btn`),x=document.getElementById(`help-modal`),S=document.getElementById(`close-help-btn`),C=document.getElementById(`help-close-footer-btn`);if(b&&x){let e=()=>{x.classList.remove(`hidden`)},t=()=>{x.classList.add(`hidden`)};b.addEventListener(`click`,e),S&&S.addEventListener(`click`,t),C&&C.addEventListener(`click`,t),x.addEventListener(`click`,e=>{e.target===x&&t()})}function w(e,t=`info`){if(t===`info`)return;let n=document.getElementById(`toast-container`);if(!n)return;let r=document.createElement(`div`);r.className=`toast toast-${t}`;let i=document.createElement(`span`);i.className=`toast-icon`,i.textContent=t===`success`?`✓`:t===`error`?`✕`:t===`warning`?`⚠`:`ℹ`;let a=document.createElement(`span`);a.className=`toast-message`,a.textContent=e,r.append(i,a),n.appendChild(r),setTimeout(()=>{r.classList.add(`toast-exit`),setTimeout(()=>r.remove(),300)},3e3)}});